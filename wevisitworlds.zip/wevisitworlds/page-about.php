<?php
defined( 'ABSPATH' ) || exit;
get_header();
$pid  = get_queried_object_id();
$f    = function ( $k, $d = '' ) use ( $pid ) { return wvw_get( $k, $pid, $d ); };
$team = get_posts( array( 'post_type' => 'team', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
$offices = wvw_rows( wvw_opt( 'offices' ) );
$email   = wvw_opt( 'contact_email', 'hello@wevisitworlds.com' );
?>
<section class="page-title"><div class="wrap"><h1 class="h1 rv"><?php echo esc_html( get_the_title( $pid ) ); ?></h1><p class="lead rv"><?php echo esc_html( $f( 'tagline' ) ); ?></p></div></section>
<?php if ( $f( 'team_image' ) ) : ?>
<div class="wrap"><div class="card team-photo" style="max-width:960px"><div class="img"><?php echo wvw_img( $f( 'team_image' ), 'large', '', false ); ?></div></div></div>
<?php endif; ?>
<section class="sec"><div class="wrap split">
	<div class="stack"><p class="eyebrow">We are</p><p class="lead rv" style="font-size:clamp(24px,2.6vw,32px)"><?php echo esc_html( $f( 'weare_lead' ) ); ?></p></div>
	<div class="stack" style="padding-top:40px"><p class="p"><?php echo esc_html( $f( 'weare_p1' ) ); ?></p><p class="p"><?php echo esc_html( $f( 'weare_p2' ) ); ?></p></div>
</div></section>
<?php if ( $team ) : ?>
<section style="padding-bottom:72px"><div class="wrap stack" style="gap:40px">
	<div class="head-row"><h2 class="h2 rv">our team</h2><p class="small"><?php echo esc_html( implode( ' · ', array_column( $offices, 0 ) ) ); ?></p></div>
	<div class="team" style="grid-template-columns:repeat(4,minmax(0,1fr))">
		<?php foreach ( $team as $m ) : $role = wvw_get( 'role', $m->ID ); ?>
			<div class="member rv"><div class="img"><?php echo wvw_img( get_post_thumbnail_id( $m ), 'medium_large', '', true, 'Portrait of ' . get_the_title( $m ) ); ?></div>
				<div class="meta"><div><b><?php echo esc_html( get_the_title( $m ) ); ?></b><span class="small"><?php echo esc_html( ( $role ? $role . ' · ' : '' ) . wvw_get( 'city', $m->ID ) ); ?></span></div></div></div>
		<?php endforeach; ?>
	</div>
</div></section>
<?php endif; ?>
<?php if ( $offices ) : ?>
<section style="padding-bottom:72px"><div class="wrap" style="display:grid;grid-template-columns:minmax(0,4fr) minmax(0,8fr);gap:64px" data-split>
	<h2 class="h2 rv">offices</h2>
	<div class="offices"><?php foreach ( $offices as $o ) : ?><div class="office rv"><b><?php echo esc_html( $o[0] ); ?></b><span class="small"><?php echo esc_html( $o[1] ?? '' ); ?></span></div><?php endforeach; ?></div>
</div></section>
<?php endif; ?>
<section class="sec-s mist"><div class="wrap head-row" style="align-items:center"><div class="stack" style="gap:10px"><h2 class="h2"><?php echo esc_html( $f( 'join_title', 'join us!' ) ); ?></h2><p class="p"><?php echo esc_html( $f( 'join_text' ) ); ?></p></div><a class="btn" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo wvw_icon( 'mail' ); ?> <?php echo esc_html( $email ); ?></a></div></section>
<?php
get_footer();
