<?php
defined( 'ABSPATH' ) || exit;
get_header();
$pid = get_queried_object_id();
$f   = function ( $k, $d = '' ) use ( $pid ) { return wvw_get( $k, $pid, $d ); };
$pdf = wvw_opt( 'credentials_pdf' );
?>
<section class="page-title pt-acc"><div class="wrap"><h1 class="h1 rv"><?php echo esc_html( get_the_title( $pid ) ); ?></h1><p class="lead rv"><?php echo esc_html( $f( 'tagline' ) ); ?></p></div></section>
<div class="wrap" style="margin-top:-12px;margin-bottom:56px"><p class="p intro-short"><?php echo esc_html( $f( 'intro' ) ); ?></p></div>

<section style="padding-bottom:72px"><div class="wrap">
<?php for ( $i = 1; $i <= 6; $i++ ) : $t = $f( "svc{$i}_title" ); if ( ! $t ) { continue; } $n = '0' . $i; ?>
	<div class="acc" id="svc-<?php echo esc_attr( $n ); ?>"><button aria-expanded="false" aria-controls="p-<?php echo esc_attr( $n ); ?>"><span class="n"><?php echo esc_html( $n ); ?></span><span class="t"><?php echo esc_html( $t ); ?></span><span class="s"><?php echo esc_html( $f( "svc{$i}_short" ) ); ?></span><?php echo wvw_icon( 'chev' ); ?></button>
		<div class="panel" id="p-<?php echo esc_attr( $n ); ?>" role="region"><div><div class="inner"><span></span><p class="p"><?php echo esc_html( $f( "svc{$i}_long" ) ); ?></p><p class="tags tags-lg"><?php foreach ( wvw_list( $f( "svc{$i}_tags" ) ) as $tag ) : ?><span><?php echo esc_html( $tag ); ?></span><?php endforeach; ?></p><span></span></div></div></div>
	</div>
<?php endfor; ?>
</div></section>

<section class="sec dark"><div class="wrap stack" style="gap:56px">
	<div class="head-row"><h2 class="h2 rv"><?php echo esc_html( $f( 'steps_title', 'how we work' ) ); ?></h2><p class="p" style="max-width:460px"><?php echo esc_html( $f( 'steps_text' ) ); ?></p></div>
	<ol class="steps">
	<?php for ( $i = 1; $i <= 6; $i++ ) : if ( ! $f( "step{$i}_title" ) ) { continue; } ?>
		<li class="rv"><b>0<?php echo (int) $i; ?></b><strong><?php echo esc_html( $f( "step{$i}_title" ) ); ?></strong><span><?php echo esc_html( $f( "step{$i}_text" ) ); ?></span></li>
	<?php endfor; ?>
	</ol>
</div></section>

<section class="sec"><div class="wrap split">
	<h2 class="h2 rv">media &amp;<br>branded content</h2>
	<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:32px">
		<div class="stack" style="gap:12px"><p class="eyebrow" style="border-top:1px solid var(--soft);padding-top:14px">Media</p><?php foreach ( wvw_lines( $f( 'media_list' ) ) as $x ) : ?><span><?php echo esc_html( $x ); ?></span><?php endforeach; ?></div>
		<div class="stack" style="gap:12px"><p class="eyebrow" style="border-top:1px solid var(--soft);padding-top:14px">Branded content</p><?php foreach ( wvw_lines( $f( 'branded_list' ) ) as $x ) : ?><span><?php echo esc_html( $x ); ?></span><?php endforeach; ?></div>
	</div>
</div></section>

<section class="sec-s mist"><div class="wrap head-row" style="align-items:center">
	<div class="stack" style="gap:10px;max-width:640px"><h2 class="h2" style="font-size:clamp(28px,3vw,38px)"><?php echo esc_html( $f( 'cred_title' ) ); ?></h2><p class="p"><?php echo esc_html( $f( 'cred_text' ) ); ?></p></div>
	<div style="display:flex;gap:12px;flex-wrap:wrap">
		<?php if ( $pdf ) : $size = size_format( (int) @filesize( get_attached_file( $pdf ) ), 0 ); ?>
			<a class="btn" href="<?php echo esc_url( wp_get_attachment_url( $pdf ) ); ?>" target="_blank" rel="noopener"><?php echo wvw_icon( 'dl' ); ?> Download credentials (PDF<?php echo $size ? ', ' . esc_html( $size ) : ''; ?>)</a>
		<?php endif; ?>
		<a class="btn btn-o" href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>">Request a proposal</a>
	</div>
</div></section>
<?php
get_footer();
