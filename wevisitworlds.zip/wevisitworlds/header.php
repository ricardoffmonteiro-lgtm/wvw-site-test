<?php
defined( 'ABSPATH' ) || exit;
$section = wvw_section();
$dark    = is_front_page();
$links   = array(
	'about'    => array( 'about', wvw_page_url( 'about' ) ),
	'work'     => array( 'our work', get_post_type_archive_link( 'case' ) ),
	'services' => array( 'services', wvw_page_url( 'services' ) ),
	'trends'   => array( 'trends', get_post_type_archive_link( 'trend' ) ),
);
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip" href="#app">Skip to content</a>
<?php if ( is_singular( 'trend' ) ) : ?><div class="readbar" id="readbar" aria-hidden="true" style="display:block"></div><?php endif; ?>

<header class="site-header<?php echo $dark ? ' on-dark' : ''; ?>" id="hdr">
	<div class="wrap bar">
		<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="We Visit Worlds, home"><img class="lb" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/wvw_black.png' ) ); ?>" alt="We Visit Worlds" width="206" height="34"><img class="lw" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/wvw_white.png' ) ); ?>" alt="We Visit Worlds" width="206" height="34"></a>
		<div class="nav">
			<a class="btn" href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>">contact us</a>
			<button class="burger" id="burger" aria-label="Open menu" aria-expanded="false" aria-controls="menu"><span></span></button>
		</div>
	</div>
</header>

<div class="menu" id="menu" role="dialog" aria-modal="true" aria-label="Menu">
	<div class="top"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="We Visit Worlds, home"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/wvw_white.png' ) ); ?>" alt="We Visit Worlds"></a><button class="close" id="menuClose" aria-label="Close menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>
	<nav class="mnav" aria-label="Main">
		<?php foreach ( $links as $k => $l ) : ?>
			<a href="<?php echo esc_url( $l[1] ); ?>"<?php echo $k === $section ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $l[0] ); ?></a>
		<?php endforeach; ?>
	</nav>
</div>

<main id="app" tabindex="-1">
