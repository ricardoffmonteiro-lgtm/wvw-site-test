<?php
/* Fallback template (search results and anything not covered elsewhere). */
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<section class="page-title"><div class="wrap"><h1 class="h1"><?php echo is_search() ? 'search' : esc_html( wp_strip_all_tags( get_the_archive_title() ) ?: get_bloginfo( 'name' ) ); ?></h1><p class="lead"></p></div></section>
<section style="padding-bottom:72px"><div class="wrap stack">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<a class="link" href="<?php the_permalink(); ?>"><?php the_title(); ?> <?php echo wvw_icon( 'arr' ); ?></a>
	<?php endwhile; else : ?>
		<p class="p">Nothing found.</p>
	<?php endif; ?>
</div></section>
<?php
get_footer();
