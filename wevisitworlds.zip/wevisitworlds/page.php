<?php
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
	the_post(); ?>
<section class="page-title"><div class="wrap"><h1 class="h1 rv"><?php the_title(); ?></h1><p class="lead rv"><?php echo esc_html( get_the_excerpt() ); ?></p></div></section>
<section style="padding-bottom:72px"><div class="wrap split"><p class="eyebrow"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p><div class="legal-text prose"><?php the_content(); ?></div></div></section>
<?php
endwhile;
get_footer();
