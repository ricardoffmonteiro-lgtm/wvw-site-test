<?php
defined( 'ABSPATH' ) || exit;
get_header(); ?>
<section class="nf"><div class="box"><p class="big">404</p><h1 style="margin:0;font-size:32px;font-weight:800;line-height:1.15">The page you are looking for does not exist.</h1><p class="p">You may have mistyped the address or the page may have moved.</p><div style="display:flex;gap:12px;flex-wrap:wrap"><a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go home</a><a class="btn btn-o" href="<?php echo esc_url( get_post_type_archive_link( 'case' ) ); ?>">See our work</a></div></div>
<?php $nf = wvw_opt( 'notfound_image' ); if ( $nf ) : ?><div class="nf-img"><?php echo wvw_img( $nf, 'full', '', false, '', '(max-width: 900px) 100vw, 50vw' ); // phpcs:ignore ?></div><?php else : ?><div style="display:flex;align-items:center;justify-content:center;color:#fff"><svg width="300" height="200" viewBox="0 0 120 80" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><rect x="20" y="8" width="80" height="52" rx="3"/><path d="M8 68h104"/><circle cx="48" cy="28" r="2.5" fill="currentColor"/><circle cx="72" cy="28" r="2.5" fill="currentColor"/><path d="M48 46c6-6 18-6 24 0"/></svg></div><?php endif; ?></section>
<?php
get_footer();
