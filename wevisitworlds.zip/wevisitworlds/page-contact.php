<?php
defined( 'ABSPATH' ) || exit;
get_header();
$pid     = get_queried_object_id();
$f       = function ( $k, $d = '' ) use ( $pid ) { return wvw_get( $k, $pid, $d ); };
$email   = wvw_opt( 'contact_email', 'hello@wevisitworlds.com' );
$phone   = wvw_opt( 'phone' );
$offices = wvw_rows( wvw_opt( 'offices' ) );
$needs   = wvw_list( $f( 'needs', 'Campaign, Strategy, Representation, Events & trade, Credentials, Other' ) );
$pre     = isset( $_GET['need'] ) ? sanitize_text_field( wp_unslash( $_GET['need'] ) ) : $needs[0]; // phpcs:ignore WordPress.Security.NonceVerification
?>
<section class="page-title pt-split-r"><div class="wrap"><h1 class="h1 rv"><?php echo esc_html( get_the_title( $pid ) ); ?></h1><p class="lead rv"><?php echo esc_html( $f( 'tagline' ) ); ?></p></div></section>
<section style="padding-bottom:72px"><div class="wrap split-r" style="align-items:start">
	<div class="form-card" id="briefCard">
		<form class="stack" style="gap:28px" data-form="brief" novalidate>
			<h2 class="h2" style="font-size:clamp(26px,2.6vw,32px)"><?php echo esc_html( $f( 'form_title', 'send us a brief' ) ); ?></h2>
			<div class="form-grid">
				<div class="field"><label for="f-name">Name</label><input id="f-name" name="name" required autocomplete="name"><span class="err">Please add your name.</span></div>
				<div class="field"><label for="f-org">Organisation</label><input id="f-org" name="org" required autocomplete="organization" placeholder="Tourism board or brand"><span class="err">Please add your organisation.</span></div>
				<div class="field"><label for="f-email">Work email</label><input id="f-email" name="email" type="email" required autocomplete="email" placeholder="name@organisation.com"><span class="err">Enter a valid email address.</span></div>
				<div class="field"><label for="f-mk">Target market</label><select id="f-mk" name="market"><option>Portugal</option><option>Spain</option><option>North America</option><option>Latin America</option><option>Several markets</option></select></div>
			</div>
			<fieldset style="border:0;margin:0;padding:0"><legend class="legend" style="padding:0 0 12px">What do you need?</legend><div style="display:flex;flex-wrap:wrap;gap:8px" data-multi>
				<?php foreach ( $needs as $n ) : ?><button type="button" class="chip" data-need="<?php echo esc_attr( $n ); ?>" aria-pressed="<?php echo $n === $pre ? 'true' : 'false'; ?>"><?php echo esc_html( $n ); ?></button><?php endforeach; ?>
			</div></fieldset>
			<div class="field"><label for="f-msg">Message</label><textarea id="f-msg" name="message" required></textarea><span class="err">Tell us a little about the project.</span></div>
			<div class="hp" aria-hidden="true"><label for="f-web">Website</label><input id="f-web" name="website" tabindex="-1" autocomplete="off"></div>
			<div class="field check"><label class="consent" for="f-ok"><input type="checkbox" id="f-ok" name="consent" required><span><?php echo esc_html( $f( 'consent', 'I agree that We Visit Worlds processes my data to reply to this request.' ) ); ?> <a href="<?php echo esc_url( wvw_page_url( 'privacy-cookies' ) ); ?>">Privacy policy</a></span></label><span class="err">Please accept so we can reply.</span></div>
			<p class="brief-error" id="briefError" role="alert"></p>
			<button class="btn" type="submit" style="align-self:flex-start">Send brief <?php echo wvw_icon( 'arr' ); ?></button>
		</form>
		<div class="done" role="status" tabindex="-1">
			<h2 class="h2" style="font-size:32px">thank you.</h2>
			<p class="p"><?php echo esc_html( $f( 'success', 'Thank you. Your brief is with us and we will reply within two working days.' ) ); ?></p>
			<div class="actions"><button class="btn btn-o" id="again" type="button">Send another brief</button></div>
		</div>
	</div>
	<div class="stack" style="gap:48px">
		<div class="direct">
			<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo wvw_icon( 'mail' ); ?><span style="flex:1"><small>Email</small><strong><?php echo esc_html( $email ); ?></strong></span><?php echo wvw_icon( 'arr' ); ?></a>
			<?php if ( $phone ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo wvw_icon( 'phone' ); ?><span style="flex:1"><small>Call</small><strong><?php echo esc_html( $phone ); ?></strong></span><?php echo wvw_icon( 'arr' ); ?></a><?php endif; ?>
			<?php if ( wvw_opt( 'linkedin_url' ) ) : ?><a href="<?php echo esc_url( wvw_opt( 'linkedin_url' ) ); ?>" target="_blank" rel="noopener"><?php echo wvw_icon( 'in' ); ?><span style="flex:1"><small>Follow</small><strong>LinkedIn</strong></span><?php echo wvw_icon( 'arr' ); ?></a><?php endif; ?>
			<?php if ( wvw_opt( 'instagram_url' ) ) : ?><a href="<?php echo esc_url( wvw_opt( 'instagram_url' ) ); ?>" target="_blank" rel="noopener"><?php echo wvw_icon( 'ig' ); ?><span style="flex:1"><small>Follow</small><strong>Instagram</strong></span><?php echo wvw_icon( 'arr' ); ?></a><?php endif; ?>
		</div>
		<?php if ( $offices ) : ?>
		<div class="stack"><p class="eyebrow">Offices</p><?php foreach ( $offices as $o ) : ?><div style="display:flex;gap:14px"><?php echo wvw_icon( 'pin' ); ?><div><p style="margin:0;font-size:19px;font-weight:800"><?php echo esc_html( $o[0] ); ?></p><p class="small"><?php echo esc_html( $o[1] ?? '' ); ?></p></div></div><?php endforeach; ?></div>
		<?php endif; ?>
	</div>
</div></section>
<?php
get_footer();
