/* We Visit Worlds: site behaviour. No dependencies. */
(function () {
  'use strict';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var doc = document, hdr = doc.getElementById('hdr');
  var $ = function (s, r) { return (r || doc).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); };

  /* Reveal (transform only; content is always visible) and number counters */
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.remove('pre'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px' });
    $$('.rv').forEach(function (el) { if (el.getBoundingClientRect().top > innerHeight) { el.classList.add('pre'); io.observe(el); } });
    var co = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { count(e.target); co.unobserve(e.target); } });
    }, { threshold: 0.6 });
    $$('[data-count]').forEach(function (el) { if (el.getBoundingClientRect().top > innerHeight) co.observe(el); });
  }
  function count(el) {
    var end = +el.dataset.count, dec = +el.dataset.dec, suf = el.dataset.suf || '', t0 = performance.now(), dur = 1400;
    function tick(t) { var p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3); el.textContent = (end * e).toFixed(dec) + suf; if (p < 1) requestAnimationFrame(tick); }
    requestAnimationFrame(tick);
  }

  /* Scroll cue on the home hero */
  $$('[data-scroll]').forEach(function (a) {
    a.addEventListener('click', function (e) { var t = $(a.getAttribute('href')); if (t) { e.preventDefault(); t.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' }); } });
  });

  /* Services accordion: all closed on load; opens the one in the address (#svc-05) when linked from the home */
  function toggleAcc(el, force) {
    var open = force === undefined ? !el.classList.contains('open') : force;
    el.classList.toggle('open', open);
    $('button', el).setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  var accs = $$('.acc');
  accs.forEach(function (a) { $('button', a).addEventListener('click', function () { toggleAcc(a); }); });
  if (accs.length) {
    var target = location.hash && $(location.hash.replace(/[^#\w-]/g, ''));
    if (target && target.classList.contains('acc')) {
      toggleAcc(target, true);
      setTimeout(function () { target.scrollIntoView({ block: 'center', behavior: reduce ? 'auto' : 'smooth' }); }, 250);
    }
  }

  /* Filters (Our work by market, Trends by topic) and "Load more" */
  $$('[data-filter]').forEach(function (g) {
    var attr = g.dataset.filter === 'mk' ? 'mk' : 'cat';
    var items = $$('#list .card'), feat = $('#featured'), featWrap = $('#featWrap'), more = $('#more');
    var limit = attr === 'cat' ? 6 : 999, cur = 'all';
    function upd(v, anim) {
      cur = v; var n = 0, shown = 0;
      items.forEach(function (c) {
        var match = v === 'all' || c.dataset[attr] === v; if (match) n++;
        var on = match && (v !== 'all' || n <= limit);
        c.classList.toggle('hide', !on);
        if (on) { shown++; if (anim) { c.classList.remove('fade'); void c.offsetWidth; c.classList.add('fade'); } }
      });
      if (featWrap && feat) featWrap.style.display = (v === 'all' || feat.dataset.cat === v) ? '' : 'none';
      if (more) more.parentElement.style.display = (v === 'all' && n > limit) ? '' : 'none';
      var cnt = $('#count'); if (cnt) cnt.textContent = 'Showing ' + shown + ' of ' + items.length + ' projects';
    }
    $$('.chip', g).forEach(function (b) {
      b.addEventListener('click', function () { $$('.chip', g).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); upd(b.dataset.v, true); });
    });
    if (more) more.addEventListener('click', function () { limit = 999; upd(cur, true); });
    upd('all', false);
  });
  /* Trends page without topic chips still needs "Load more" */
  if (!$('[data-filter]') && $('#more')) {
    var cards = $$('#list .card');
    if (cards.length > 6) { cards.slice(6).forEach(function (c) { c.classList.add('hide'); }); }
    else { $('#more').parentElement.style.display = 'none'; }
    $('#more').addEventListener('click', function () { cards.forEach(function (c) { c.classList.remove('hide'); }); this.parentElement.style.display = 'none'; });
  }
  var cntEl = $('#count'); if (cntEl && !cntEl.textContent) { var n = $$('#list .card').length; cntEl.textContent = 'Showing ' + n + ' of ' + n + ' projects'; }

  /* Multi-select chips in the brief form */
  $$('[data-multi] .chip').forEach(function (b) {
    b.addEventListener('click', function () { b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); });
  });

  /* Work carousel on the home page */
  var car = $('#car');
  if (car && $('.card', car)) {
    var bar = $('#carBar'), btns = $$('[data-car]');
    var step = function () { return $('.card', car).getBoundingClientRect().width + 28; };
    var updCar = function () {
      var max = car.scrollWidth - car.clientWidth, p = max > 0 ? car.scrollLeft / max : 0, w = Math.max(0.2, car.clientWidth / car.scrollWidth);
      bar.style.width = (w * 100) + '%'; bar.style.left = (p * (1 - w) * 100) + '%';
      btns[0].disabled = car.scrollLeft < 4; btns[1].disabled = car.scrollLeft > max - 4;
    };
    btns.forEach(function (b) { b.addEventListener('click', function () { car.scrollBy({ left: step() * +b.dataset.car, behavior: reduce ? 'auto' : 'smooth' }); }); });
    car.addEventListener('scroll', updCar, { passive: true }); addEventListener('resize', updCar); updCar();
    var down = false, sx = 0, sl = 0, moved = false;
    car.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') return; down = true; moved = false; sx = e.clientX; sl = car.scrollLeft; car.style.scrollSnapType = 'none'; });
    addEventListener('pointermove', function (e) { if (!down) return; var dx = e.clientX - sx; if (Math.abs(dx) > 4) moved = true; car.scrollLeft = sl - dx; });
    addEventListener('pointerup', function () { if (!down) return; down = false; car.style.scrollSnapType = ''; });
    car.addEventListener('click', function (e) { if (moved) { e.preventDefault(); moved = false; } }, true);
  }

  /* Lightbox for case galleries */
  var lb = $('#lightbox'), lbImg = $('#lbImg'), lbClose = $('#lbClose'), lastFocus = null;
  function closeLb() { lb.classList.remove('open'); if (lastFocus) lastFocus.focus(); }
  $$('[data-lb]').forEach(function (b) {
    b.addEventListener('click', function () { var im = $('img', b); lbImg.src = b.dataset.lb; lbImg.alt = im ? im.alt : ''; lb.classList.add('open'); lastFocus = b; lbClose.focus(); });
  });
  if (lb) { lbClose.addEventListener('click', closeLb); lb.addEventListener('click', function (e) { if (e.target === lb) closeLb(); }); }

  /* Copy link on articles */
  var cp = $('#copyLink');
  if (cp) cp.addEventListener('click', function () {
    var m = $('#copyMsg'), fail = function () { m.textContent = 'Copy the address from the browser bar.'; };
    try { navigator.clipboard.writeText(location.href).then(function () { m.textContent = 'Link copied.'; }, fail); } catch (e) { fail(); }
  });

  /* Brief form */
  var form = $('form[data-form="brief"]');
  if (form) {
    var started = Date.now();
    var validate = function (i) {
      var f = i.closest('.field'), ok = i.type === 'checkbox' ? i.checked : i.value.trim().length > 0;
      if (ok && i.type === 'email') ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(i.value.trim());
      f.classList.toggle('invalid', !ok); i.setAttribute('aria-invalid', !ok); return ok;
    };
    $$('input,textarea', form).forEach(function (i) { i.addEventListener('input', function () { if (i.closest('.field') && i.closest('.field').classList.contains('invalid')) validate(i); }); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var ok = true, first = null;
      $$('[required]', form).forEach(function (i) { if (!validate(i)) { ok = false; first = first || i; } });
      if (!ok) { first.focus(); return; }
      var btn = $('button[type=submit]', form), err = $('#briefError');
      var v = function (n) { var el = form.elements[n]; return el ? el.value.trim() : ''; };
      var data = {
        name: v('name'), org: v('org'), email: v('email'), market: v('market'), message: v('message'),
        needs: $$('[data-multi] .chip[aria-pressed="true"]', form).map(function (b) { return b.dataset.need; }),
        consent: form.elements.consent.checked, website: v('website'), t: started
      };
      btn.disabled = true; err.classList.remove('show');
      fetch(window.WVW.briefUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok && j.ok, j: j }; }); })
        .then(function (res) {
          if (!res.ok) throw new Error(res.j && res.j.error ? res.j.error : 'error');
          $('#briefCard').classList.add('sent'); $('.done').focus(); form.reset(); started = Date.now();
        })
        .catch(function (ex) {
          err.textContent = (ex && ex.message && ex.message !== 'error' ? ex.message + ' ' : 'Something went wrong. ') + 'You can also email us at ' + window.WVW.email + '.';
          err.classList.add('show');
        })
        .finally(function () { btn.disabled = false; });
    });
    var again = $('#again'); if (again) again.addEventListener('click', function () { $('#briefCard').classList.remove('sent'); });
  }

  /* Header: compact after scrolling, hides going down, shows going up. Sticky CTA and reading bar. */
  var menu = $('#menu'), burger = $('#burger'), lastY = 0, sc = $('#stickyCta'), rb = $('#readbar');
  addEventListener('scroll', function () {
    var y = scrollY;
    hdr.classList.toggle('compact', y > 40);
    if (doc.body.classList.contains('admin-bar')) hdr.style.top = (window.innerWidth <= 600 ? Math.max(0, 46 - y) + 'px' : '');
    if (!menu.classList.contains('open')) {
      if (y > 400 && y > lastY + 2) hdr.classList.add('hidden');
      else if (y < lastY - 2 || y < 100) hdr.classList.remove('hidden');
    }
    if (sc) sc.classList.toggle('show', y > 500 && (innerHeight + y) < doc.body.scrollHeight - 700);
    if (rb) { var max = doc.body.scrollHeight - innerHeight; rb.style.width = (max > 0 ? y / max * 100 : 0) + '%'; }
    lastY = y;
  }, { passive: true });

  /* Menu */
  function openMenu() { menu.classList.add('open'); burger.setAttribute('aria-expanded', 'true'); doc.body.style.overflow = 'hidden'; setTimeout(function () { $('#menuClose').focus(); }, 50); }
  function closeMenu() { if (!menu.classList.contains('open')) return; menu.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); doc.body.style.overflow = ''; burger.focus(); }
  burger.addEventListener('click', openMenu);
  $('#menuClose').addEventListener('click', closeMenu);
  menu.addEventListener('keydown', function (e) {
    if (e.key !== 'Tab') return;
    var f = $$('a,button', menu), first = f[0], last = f[f.length - 1];
    if (e.shiftKey && doc.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && doc.activeElement === last) { e.preventDefault(); first.focus(); }
  });
  addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (lb && lb.classList.contains('open')) closeLb(); else closeMenu(); } });

  /* Skip link focuses the main content */
  var skip = $('.skip'); if (skip) skip.addEventListener('click', function (e) { e.preventDefault(); $('#app').focus(); });
})();

/* Logo carousel: pause/play button (WCAG 2.2.2), also pauses while a logo has keyboard focus */
(function () {
  var b = document.querySelector('.mq-toggle'), m = document.querySelector('.marquee');
  if (!b || !m) { return; }
  b.addEventListener('click', function () {
    var paused = m.classList.toggle('paused');
    b.setAttribute('aria-pressed', paused ? 'true' : 'false');
    b.setAttribute('aria-label', paused ? 'Play logo carousel' : 'Pause logo carousel');
  });
})();
