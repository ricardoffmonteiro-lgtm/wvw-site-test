<?php
defined( 'ABSPATH' ) || exit;
get_header();
the_post();
$id      = get_the_ID();
$all     = get_posts( array( 'post_type' => 'trend', 'numberposts' => -1, 'fields' => 'ids' ) );
$idx     = array_search( $id, $all, true );
$others  = array();
for ( $k = 1; $k <= min( 3, count( $all ) - 1 ); $k++ ) {
	$others[] = $all[ ( $idx + $k ) % count( $all ) ];
}
$sources = wvw_rows( wvw_get( 'sources' ) );
$share   = 'https://www.linkedin.com/sharing/share-offsite/?url=' . rawurlencode( get_permalink() );
?>
<div class="wrap" style="padding-top:24px"><a class="link back" href="<?php echo esc_url( get_post_type_archive_link( 'trend' ) ); ?>"><?php echo wvw_icon( 'larr' ); ?> Trends</a></div>
<article>
<section style="padding:24px 0 56px"><div class="wrap split-r" style="align-items:end">
	<div class="stack" style="gap:22px"><p class="eyebrow"><?php echo esc_html( wvw_get( 'category' ) ); ?> · <time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'j M Y' ) ); ?></time> · <?php echo (int) wvw_reading_time(); ?> min read</p>
		<h1 style="margin:0;font-size:clamp(34px,4.4vw,62px);font-weight:800;line-height:1.04;letter-spacing:-.03em;text-wrap:balance"><?php the_title(); ?></h1>
		<p class="small">By We Visit Worlds</p></div>
	<div class="card"><div class="img" style="height:360px"><?php echo wvw_trend_cover( $id, 1 ); ?></div></div>
</div></section>
<section style="padding-bottom:64px"><div class="wrap article">
	<aside><p class="eyebrow">Share</p><div style="display:flex;gap:10px;flex-wrap:wrap"><a class="btn btn-o" href="<?php echo esc_url( $share ); ?>" rel="noopener" style="min-height:48px;padding:0 18px;font-size:15px"><?php echo wvw_icon( 'in' ); ?> LinkedIn</a><button class="btn btn-o" id="copyLink" type="button" style="min-height:48px;padding:0 18px;font-size:15px">Copy link</button></div><p class="small" id="copyMsg" aria-live="polite"></p></aside>
	<div class="prose">
		<?php the_content(); ?>
		<?php if ( $sources ) : ?>
			<div class="sources"><p class="eyebrow">Sources</p><?php foreach ( $sources as $s ) : ?><a href="<?php echo esc_url( $s[1] ?? '#' ); ?>" rel="noopener"><?php echo esc_html( $s[0] ); ?></a><?php endforeach; ?></div>
		<?php endif; ?>
	</div>
</div></section>
</article>
<?php if ( $others ) : ?>
<section style="border-top:1px solid var(--line);padding:56px 0 72px"><div class="wrap stack" style="gap:32px"><p class="eyebrow">Read next</p><div class="grid3"><?php foreach ( $others as $i => $o ) { echo wvw_trend_card( $o, 220, $i ); } // phpcs:ignore ?></div></div></section>
<?php endif; ?>
<?php
get_footer();
