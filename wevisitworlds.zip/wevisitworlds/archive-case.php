<?php
defined( 'ABSPATH' ) || exit;
get_header();
$used = array();
while ( have_posts() ) {
	the_post();
	$used[ wvw_get( 'market_key' ) ] = true;
}
rewind_posts();
$markets = array_intersect_key( wvw_markets(), $used );
?>
<section class="page-title"><div class="wrap"><h1 class="h1 rv"><?php echo esc_html( wvw_opt( 'work_title', 'our work' ) ); ?></h1><p class="lead rv"><?php echo esc_html( wvw_opt( 'work_lead' ) ); ?></p></div></section>
<?php if ( count( $markets ) > 1 ) : ?>
<section style="border-top:1px solid var(--line);border-bottom:1px solid var(--line)"><div class="wrap chips-scroll" role="group" aria-label="Filter by market" style="display:flex;flex-wrap:wrap;gap:10px;padding-top:24px;padding-bottom:24px" data-filter="mk">
	<button class="chip" data-v="all" aria-pressed="true">All</button>
	<?php foreach ( $markets as $k => $l ) : ?><button class="chip" data-v="<?php echo esc_attr( $k ); ?>" aria-pressed="false"><?php echo esc_html( $l ); ?></button><?php endforeach; ?>
</div></section>
<?php endif; ?>
<section style="padding:56px 0 64px"><div class="wrap">
	<div class="grid2" id="list"><?php while ( have_posts() ) { the_post(); echo wvw_case_card( get_post(), true ); } // phpcs:ignore ?></div>
	<p class="small" id="count" style="text-align:center;padding-top:56px" aria-live="polite"></p>
</div></section>
<?php
get_footer();
