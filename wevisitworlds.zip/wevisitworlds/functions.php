<?php
defined( 'ABSPATH' ) || exit;

define( 'WVW_THEME_VERSION', '1.0.0' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v = WVW_THEME_VERSION;
	wp_enqueue_style( 'wvw-site', get_theme_file_uri( 'assets/css/site.css' ), array(), $v );
	wp_enqueue_script( 'wvw-main', get_theme_file_uri( 'assets/js/main.js' ), array(), $v, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'wvw-main', 'WVW', array(
		'briefUrl' => esc_url_raw( rest_url( 'wvw/v1/brief' ) ),
		'email'    => function_exists( 'wvw_opt' ) ? wvw_opt( 'contact_email', 'hello@wevisitworlds.com' ) : 'hello@wevisitworlds.com',
	) );
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );
}, 20 );

add_action( 'wp_head', function () {
	foreach ( array( 700, 800 ) as $w ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( get_theme_file_uri( "assets/fonts/montserrat-latin-{$w}-normal.woff2" ) ) );
	}
}, 1 );

/* The theme needs the WVW Core plugin. */
add_action( 'admin_notices', function () {
	if ( ! function_exists( 'wvw_get' ) ) {
		echo '<div class="notice notice-error"><p><strong>We Visit Worlds:</strong> ative o plugin “WVW Core”. O tema precisa dele para funcionar.</p></div>';
	}
} );
if ( ! function_exists( 'wvw_get' ) && ! is_admin() ) {
	add_action( 'template_redirect', function () {
		wp_die( 'Site em manutenção.', 'We Visit Worlds', array( 'response' => 503 ) );
	} );
	return;
}

/* ---------- small helpers ---------- */

function wvw_icon( $name ) {
	$i = array(
		'arr'   => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
		'larr'  => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
		'chev'  => '<svg class="ic" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
		'in'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18"/><path d="M8 10v7M8 7v.01M12 17v-4a2 2 0 0 1 4 0v4M12 10v7"/></svg>',
		'mail'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14"/><path d="M3 7l9 6 9-6"/></svg>',
		'phone' => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>',
		'pin'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s-7-6.5-7-12a7 7 0 0 1 14 0c0 5.5-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>',
		'dl'    => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>',
		'medal' => '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="9" r="6"/><path d="M8.5 14L7 22l5-3 5 3-1.5-8"/></svg>',
	);
	return $i[ $name ] ?? '';
}

/** Image by attachment id, with srcset; $class on the <img>. */
function wvw_img( $id, $size = 'large', $class = '', $lazy = true, $alt = null ) {
	if ( ! $id ) {
		return '';
	}
	$attr = array( 'class' => $class, 'loading' => $lazy ? 'lazy' : 'eager', 'decoding' => 'async' );
	if ( null !== $alt ) {
		$attr['alt'] = $alt;
	}
	return wp_get_attachment_image( (int) $id, $size, false, $attr );
}

function wvw_page_url( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? get_permalink( $p ) : home_url( '/' . $slug . '/' );
}

/** The section of the site the current view belongs to (for the menu). */
function wvw_section() {
	if ( is_post_type_archive( 'case' ) || is_singular( 'case' ) ) {
		return 'work';
	}
	if ( is_post_type_archive( 'trend' ) || is_singular( 'trend' ) ) {
		return 'trends';
	}
	if ( is_page() ) {
		return get_post_field( 'post_name', get_queried_object_id() );
	}
	return '';
}

/** Case card (carousel, grids). */
function wvw_case_card( $post, $extra = false ) {
	$id    = is_object( $post ) ? $post->ID : (int) $post;
	$award = wvw_get( 'award', $id );
	ob_start(); ?>
	<a class="card rv" href="<?php echo esc_url( get_permalink( $id ) ); ?>" data-mk="<?php echo esc_attr( wvw_get( 'market_key', $id ) ); ?>">
		<div class="img kv"><?php echo wvw_img( get_post_thumbnail_id( $id ), 'large', '', true, get_the_title( $id ) . ' key visual' ); ?><?php if ( $award ) : ?><span class="badge"><?php echo esc_html( preg_replace( '/,\s*/', ' · ', $award, 1 ) ); ?></span><?php endif; ?></div>
		<p class="eyebrow"><?php echo esc_html( wvw_get( 'market_label', $id ) ); ?></p>
		<p class="t"><?php echo esc_html( get_the_title( $id ) ); ?></p>
		<?php if ( $extra ) : ?>
			<p class="p"><?php echo esc_html( wvw_get( 'summary', $id ) ); ?></p>
			<div style="display:flex;flex-wrap:wrap;gap:8px"><?php foreach ( wvw_list( wvw_get( 'tags', $id ) ) as $t ) : ?><span class="tag"><?php echo esc_html( $t ); ?></span><?php endforeach; ?></div>
			<span class="arr">View project <?php echo wvw_icon( 'arr' ); ?></span>
		<?php endif; ?>
	</a>
	<?php
	return ob_get_clean();
}

/** Article cover: featured image, or a typographic cover with the key number. */
function wvw_trend_cover( $id, $i = 0 ) {
	$thumb = get_post_thumbnail_id( $id );
	if ( $thumb ) {
		return wvw_img( $thumb, 'large', '', true, '' );
	}
	return '<div class="cover' . ( $i % 2 ? ' alt' : '' ) . '"><small>' . esc_html( wvw_get( 'category', $id ) ) . '</small><b>' . esc_html( wvw_get( 'cover_value', $id ) ) . '</b><span>' . esc_html( wvw_get( 'cover_label', $id ) ) . '</span></div>';
}

function wvw_trend_card( $post, $h = 250, $i = 0 ) {
	$id = is_object( $post ) ? $post->ID : (int) $post;
	ob_start(); ?>
	<a class="card rv" href="<?php echo esc_url( get_permalink( $id ) ); ?>" data-cat="<?php echo esc_attr( wvw_get( 'category', $id ) ); ?>">
		<div class="img" style="height:<?php echo (int) $h; ?>px"><?php echo wvw_trend_cover( $id, $i ); ?></div>
		<p class="small"><strong style="color:var(--ink)"><?php echo esc_html( wvw_get( 'category', $id ) ); ?></strong> · <time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d', $id ) ); ?>"><?php echo esc_html( get_the_date( 'j M Y', $id ) ); ?></time></p>
		<p class="t sm"><?php echo esc_html( get_the_title( $id ) ); ?></p>
	</a>
	<?php
	return ob_get_clean();
}

function wvw_kpi_html( $kpis, $cols = 2 ) {
	$o = '<div class="kpis" style="--cols:' . (int) $cols . '">';
	foreach ( $kpis as $k ) {
		$o .= '<div class="kpi rv">' . ( $k['label'] ? '<span class="eyebrow">' . esc_html( $k['label'] ) . '</span>' : '' ) .
			'<b class="tnum" data-count="' . esc_attr( $k['value'] ) . '" data-dec="' . (int) $k['dec'] . '" data-suf="' . esc_attr( $k['suf'] ) . '">' .
			esc_html( number_format( $k['value'], $k['dec'], '.', '' ) . $k['suf'] ) . '</b><span>' . esc_html( $k['desc'] ) . '</span></div>';
	}
	return $o . '</div>';
}

/* ---------- SEO basics (no plugin needed) ---------- */
add_filter( 'document_title_separator', function () {
	return '|';
} );
add_filter( 'document_title_parts', function ( $t ) {
	if ( is_front_page() ) {
		$t['title'] = 'We Visit Worlds';
		$t['tagline'] = 'Tourism marketing & communication';
	} elseif ( is_singular() || is_post_type_archive() ) {
		$t['title'] = ucfirst( wp_strip_all_tags( $t['title'] ) );
	}
	return $t;
} );
add_action( 'wp_head', function () {
	$desc = wvw_opt( 'seo_description' );
	$img  = wvw_opt( 'og_image' );
	if ( is_singular( 'case' ) ) {
		$desc = wvw_get( 'summary', null, $desc );
	} elseif ( is_singular( 'trend' ) ) {
		$desc = get_the_excerpt() ?: $desc;
	} elseif ( is_post_type_archive( 'case' ) ) {
		$desc = wvw_opt( 'work_lead', $desc );
	} elseif ( is_post_type_archive( 'trend' ) ) {
		$desc = wvw_opt( 'trends_lead', $desc );
	} elseif ( is_page() && wvw_get( 'tagline' ) && ! is_front_page() ) {
		$desc = wvw_get( 'tagline' );
	}
	if ( is_singular() && has_post_thumbnail() ) {
		$img = get_post_thumbnail_id();
	}
	$url   = is_singular() ? get_permalink() : ( is_post_type_archive() ? get_post_type_archive_link( get_query_var( 'post_type' ) ) : home_url( '/' ) );
	$title = wp_get_document_title();
	echo '<meta name="description" content="' . esc_attr( wp_trim_words( $desc, 30, '' ) ) . '">' . "\n";
	echo '<meta property="og:type" content="' . ( is_singular( 'trend' ) ? 'article' : 'website' ) . '">' . "\n";
	echo '<meta property="og:site_name" content="We Visit Worlds">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( wp_trim_words( $desc, 30, '' ) ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	if ( $img ) {
		echo '<meta property="og:image" content="' . esc_url( wp_get_attachment_image_url( $img, 'large' ) ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="theme-color" content="#0A0A0A">' . "\n";
	if ( is_front_page() ) {
		$org = array(
			'@context'  => 'https://schema.org',
			'@type'     => 'Organization',
			'name'      => 'We Visit Worlds',
			'legalName' => wvw_opt( 'legal_name', 'We Visit Worlds, Lda' ),
			'url'       => home_url( '/' ),
			'email'     => wvw_opt( 'contact_email' ),
			'address'   => array( '@type' => 'PostalAddress', 'addressLocality' => 'Porto', 'addressCountry' => 'PT' ),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $org ) . '</script>' . "\n";
	}
}, 5 );

/* Favicon fallback when no Site Icon is set in Appearance › Customise. */
add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 fill=%27%230A0A0A%27/%3E%3Ctext x=%2732%27 y=%2746%27 font-family=%27Arial Black,Arial%27 font-weight=%27900%27 font-size=%2738%27 fill=%27white%27 text-anchor=%27middle%27%3EW%3C/text%3E%3C/svg%3E">' . "\n";
	}
} );

/* Archive titles: no "Archives:" prefix. */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );
