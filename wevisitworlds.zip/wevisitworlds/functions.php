<?php
defined( 'ABSPATH' ) || exit;

define( 'WVW_THEME_VERSION', '1.2.0' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v = WVW_THEME_VERSION;
	wp_enqueue_style( 'wvw-site', get_theme_file_uri( 'assets/css/site.css' ), array(), $v );
	wp_enqueue_script( 'wvw-main', get_theme_file_uri( 'assets/js/main.js' ), array(), $v, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'wvw-main', 'WVW', array(
		'briefUrl' => esc_url_raw( rest_url( 'wvw/v1/brief' ) ),
		'email'    => function_exists( 'wvw_opt' ) ? wvw_opt( 'contact_email', 'hello@wevisitworlds.com' ) : 'hello@wevisitworlds.com',
	) );
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'classic-theme-styles' );
}, 20 );

add_action( 'wp_head', function () {
	foreach ( array( 700, 800 ) as $w ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( get_theme_file_uri( "assets/fonts/montserrat-latin-{$w}-normal.woff2" ) ) );
	}
}, 1 );

/* The theme needs the WVW Core plugin. */
add_action( 'admin_notices', function () {
	if ( ! function_exists( 'wvw_get' ) ) {
		echo '<div class="notice notice-error"><p><strong>We Visit Worlds:</strong> ative o plugin “WVW Core”. O tema precisa dele para funcionar.</p></div>';
	}
} );
if ( ! function_exists( 'wvw_get' ) && ! is_admin() ) {
	add_action( 'template_redirect', function () {
		wp_die( 'Site em manutenção.', 'We Visit Worlds', array( 'response' => 503 ) );
	} );
	return;
}

/* ---------- small helpers ---------- */

function wvw_icon( $name ) {
	$i = array(
		'arr'   => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
		'larr'  => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>',
		'chev'  => '<svg class="ic" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>',
		'in'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18"/><path d="M8 10v7M8 7v.01M12 17v-4a2 2 0 0 1 4 0v4M12 10v7"/></svg>',
		'ig'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6" fill="currentColor"/></svg>',
		'mail'  => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14"/><path d="M3 7l9 6 9-6"/></svg>',
		'phone' => '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg>',
		'pin'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21s-7-6.5-7-12a7 7 0 0 1 14 0c0 5.5-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/></svg>',
		'dl'    => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>',
		'medal' => '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="9" r="6"/><path d="M8.5 14L7 22l5-3 5 3-1.5-8"/></svg>',
	);
	return $i[ $name ] ?? '';
}

/** Image by attachment id, with srcset; $class on the <img>. */
function wvw_img( $id, $size = 'large', $class = '', $lazy = true, $alt = null, $sizes = '' ) {
	if ( ! $id ) {
		return '';
	}
	$attr = array( 'class' => $class, 'loading' => $lazy ? 'lazy' : 'eager', 'decoding' => 'async' );
	if ( null !== $alt ) {
		$attr['alt'] = $alt;
	}
	if ( $sizes ) {
		$attr['sizes'] = $sizes; // tells the browser the displayed width, so it downloads the right file
	}
	if ( ! $lazy ) {
		$attr['fetchpriority'] = 'high';
	}
	return wp_get_attachment_image( (int) $id, $size, false, $attr );
}

function wvw_page_url( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? get_permalink( $p ) : home_url( '/' . $slug . '/' );
}

/** The section of the site the current view belongs to (for the menu). */
function wvw_section() {
	if ( is_post_type_archive( 'case' ) || is_singular( 'case' ) ) {
		return 'work';
	}
	if ( is_post_type_archive( 'trend' ) || is_singular( 'trend' ) ) {
		return 'trends';
	}
	if ( is_page() ) {
		return get_post_field( 'post_name', get_queried_object_id() );
	}
	return '';
}

/** Case card (carousel, grids). */
function wvw_case_card( $post, $extra = false, $badge = true ) {
	$id    = is_object( $post ) ? $post->ID : (int) $post;
	$award = $badge ? wvw_get( 'award', $id ) : '';
	ob_start(); ?>
	<a class="card rv" href="<?php echo esc_url( get_permalink( $id ) ); ?>" data-mk="<?php echo esc_attr( wvw_get( 'market_key', $id ) ); ?>">
		<div class="img kv"><?php echo wvw_img( get_post_thumbnail_id( $id ), 'large', '', true, get_the_title( $id ) . ' key visual', '(max-width: 720px) 100vw, (max-width: 1100px) 50vw, 620px' ); ?><?php if ( $award ) : ?><span class="badge"><?php echo esc_html( preg_replace( '/,\s*/', ' · ', $award, 1 ) ); ?></span><?php endif; ?></div>
		<p class="eyebrow"><?php echo esc_html( wvw_get( 'market_label', $id ) ); ?></p>
		<p class="t"><?php echo esc_html( get_the_title( $id ) ); ?></p>
		<?php if ( $extra ) : ?>
			<p class="p"><?php echo esc_html( wvw_get( 'summary', $id ) ); ?></p>
			<p class="tags"><?php foreach ( wvw_list( wvw_get( 'tags', $id ) ) as $t ) : ?><span><?php echo esc_html( $t ); ?></span><?php endforeach; ?></p>
			<span class="arr">View project <?php echo wvw_icon( 'arr' ); ?></span>
		<?php endif; ?>
	</a>
	<?php
	return ob_get_clean();
}

/** Article cover: featured image, or a typographic cover with the key number. */
function wvw_trend_cover( $id, $i = 0 ) {
	$thumb = get_post_thumbnail_id( $id );
	if ( $thumb ) {
		return wvw_img( $thumb, 'large', '', true, '', '(max-width: 720px) 100vw, 420px' );
	}
	return '<div class="cover' . ( $i % 2 ? ' alt' : '' ) . '"><small>' . esc_html( wvw_get( 'category', $id ) ) . '</small><b>' . esc_html( wvw_get( 'cover_value', $id ) ) . '</b><span>' . esc_html( wvw_get( 'cover_label', $id ) ) . '</span></div>';
}

function wvw_trend_card( $post, $h = 250, $i = 0 ) {
	$id = is_object( $post ) ? $post->ID : (int) $post;
	ob_start(); ?>
	<a class="card rv" href="<?php echo esc_url( get_permalink( $id ) ); ?>" data-cat="<?php echo esc_attr( wvw_get( 'category', $id ) ); ?>">
		<div class="img" style="height:<?php echo (int) $h; ?>px"><?php echo wvw_trend_cover( $id, $i ); ?></div>
		<p class="small"><strong style="color:var(--ink)"><?php echo esc_html( wvw_get( 'category', $id ) ); ?></strong> · <time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d', $id ) ); ?>"><?php echo esc_html( get_the_date( 'j M Y', $id ) ); ?></time></p>
		<p class="t sm"><?php echo esc_html( get_the_title( $id ) ); ?></p>
	</a>
	<?php
	return ob_get_clean();
}

function wvw_kpi_html( $kpis, $cols = 2 ) {
	$o = '<div class="kpis" style="--cols:' . (int) $cols . '">';
	foreach ( $kpis as $k ) {
		$o .= '<div class="kpi rv">' . ( $k['label'] ? '<span class="eyebrow">' . esc_html( $k['label'] ) . '</span>' : '' ) .
			'<b class="tnum" data-count="' . esc_attr( $k['value'] ) . '" data-dec="' . (int) $k['dec'] . '" data-suf="' . esc_attr( $k['suf'] ) . '">' .
			esc_html( number_format( $k['value'], $k['dec'], '.', '' ) . $k['suf'] ) . '</b><span>' . esc_html( $k['desc'] ) . '</span></div>';
	}
	return $o . '</div>';
}

/* Keep hyphens and quotes exactly as typed (WordPress would turn " - " into a long dash). */
add_filter( 'run_wptexturize', '__return_false' );

/* ---------- SEO basics (no plugin needed) ---------- */

/* The site is written in British English, whatever language the WordPress admin uses. */
add_filter( 'language_attributes', function ( $out ) {
	return is_admin() ? $out : 'lang="en-GB"';
} );

add_filter( 'document_title_separator', function () {
	return '|';
} );
add_filter( 'document_title_parts', function ( $t ) {
	if ( is_front_page() ) {
		$t['title']   = 'We Visit Worlds';
		$t['tagline'] = 'Tourism marketing & communication agency';
	} elseif ( is_post_type_archive( 'case' ) ) {
		$t['title'] = ucfirst( wvw_opt( 'work_title', 'our work' ) );
	} elseif ( is_post_type_archive( 'trend' ) ) {
		$t['title'] = ucfirst( wvw_opt( 'trends_title', 'trends' ) ) . ': tourism insights';
	} elseif ( is_singular( 'case' ) ) {
		$t['title'] = 'Case study: ' . wvw_title_case( $t['title'] );
	} elseif ( is_singular() ) {
		$t['title'] = ucfirst( wp_strip_all_tags( $t['title'] ) );
	}
	return $t;
} );

/* Trim to a length Google shows in full (about 155 characters), cutting at a word. */
function wvw_meta_trim( $text, $max = 158 ) {
	$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( (string) $text ) ) ) );
	if ( mb_strlen( $text ) <= $max ) {
		return $text;
	}
	$cut = mb_substr( $text, 0, $max - 1 );
	return rtrim( mb_substr( $cut, 0, (int) mb_strrpos( $cut, ' ' ) ), ' ,.;:-' ) . '…';
}

function wvw_meta_description() {
	$desc = wvw_opt( 'seo_description' );
	if ( is_singular() && wvw_get( 'seo_desc' ) ) {
		return wvw_meta_trim( wvw_get( 'seo_desc' ) );
	}
	if ( is_front_page() ) {
		$desc = wvw_get( 'seo_desc', (int) get_option( 'page_on_front' ), $desc );
	} elseif ( is_singular( 'case' ) ) {
		$desc = wvw_get( 'summary', null, $desc );
	} elseif ( is_singular( 'trend' ) ) {
		$desc = get_the_excerpt() ?: $desc;
	} elseif ( is_post_type_archive( 'case' ) ) {
		$desc = wvw_opt( 'work_lead', $desc );
	} elseif ( is_post_type_archive( 'trend' ) ) {
		$desc = wvw_opt( 'trends_lead', $desc );
	} elseif ( is_page() && wvw_get( 'tagline' ) ) {
		$desc = wvw_get( 'tagline' );
	}
	return wvw_meta_trim( $desc );
}

function wvw_current_url() {
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_singular() ) {
		return get_permalink();
	}
	if ( is_post_type_archive() ) {
		return get_post_type_archive_link( get_query_var( 'post_type' ) );
	}
	return '';
}

/* Error and search pages stay out of Google. */
add_filter( 'wp_robots', function ( $r ) {
	if ( is_404() || is_search() ) {
		$r['noindex'] = true;
		$r['follow']  = true;
	}
	return $r;
} );

/* Canonical for archives (WordPress only prints it on single pages). */
add_action( 'wp_head', function () {
	if ( is_post_type_archive() && ! is_paged() ) {
		echo '<link rel="canonical" href="' . esc_url( wvw_current_url() ) . '">' . "\n";
	}
}, 4 );

add_action( 'wp_head', function () {
	$desc  = wvw_meta_description();
	$img   = wvw_opt( 'og_image' );
	if ( is_singular() && has_post_thumbnail() ) {
		$img = get_post_thumbnail_id();
	}
	$url   = wvw_current_url();
	$title = wp_get_document_title();
	echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:locale" content="en_GB">' . "\n";
	echo '<meta property="og:type" content="' . ( is_singular( 'trend' ) ? 'article' : 'website' ) . '">' . "\n";
	echo '<meta property="og:site_name" content="We Visit Worlds">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	if ( $url ) {
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	}
	if ( $img ) {
		$src = wp_get_attachment_image_src( $img, 'large' );
		if ( $src ) {
			echo '<meta property="og:image" content="' . esc_url( $src[0] ) . '">' . "\n";
			echo '<meta property="og:image:width" content="' . (int) $src[1] . '">' . "\n";
			echo '<meta property="og:image:height" content="' . (int) $src[2] . '">' . "\n";
		}
	}
	if ( is_singular( 'trend' ) ) {
		echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c' ) ) . '">' . "\n";
		echo '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . "\n";
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="theme-color" content="#0A0A0A">' . "\n";
	$graph = wvw_schema_graph( $desc, $url );
	if ( $graph ) {
		echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}, 5 );

/* Structured data (schema.org): tells Google and AI assistants who WVW is and what each page is. */
function wvw_schema_graph( $desc, $url ) {
	$home    = home_url( '/' );
	$org_id  = $home . '#organization';
	$site_id = $home . '#website';
	$offices = array_map( function ( $o ) {
		return array( '@type' => 'Place', 'name' => $o[0] . ' office', 'address' => array( '@type' => 'PostalAddress', 'addressLocality' => $o[0] ) );
	}, wvw_rows( wvw_opt( 'offices' ) ) );
	$org = array(
		'@type'       => 'Organization',
		'@id'         => $org_id,
		'name'        => 'We Visit Worlds',
		'legalName'   => wvw_opt( 'legal_name', 'We Visit Worlds, Lda' ),
		'url'         => $home,
		'logo'        => array( '@type' => 'ImageObject', 'url' => get_theme_file_uri( 'assets/img/wvw_black.png' ) ),
		'description' => wvw_meta_trim( wvw_opt( 'seo_description' ), 300 ),
		'email'       => wvw_opt( 'contact_email' ),
		'address'     => array( '@type' => 'PostalAddress', 'addressLocality' => 'Porto', 'addressCountry' => 'PT' ),
		'location'    => $offices,
		'areaServed'  => array( 'Portugal', 'Spain', 'United States', 'Canada', 'Brazil', 'Argentina' ),
		'knowsAbout'  => array( 'Destination marketing', 'Tourism communication', 'Travel trade marketing', 'Media planning', 'Destination representation' ),
		'sameAs'      => array_values( array_filter( array( wvw_opt( 'linkedin_url' ), wvw_opt( 'instagram_url' ) ) ) ),
	);
	if ( wvw_opt( 'phone' ) ) {
		$org['telephone'] = wvw_opt( 'phone' );
	}
	$graph = array(
		$org,
		array( '@type' => 'WebSite', '@id' => $site_id, 'url' => $home, 'name' => 'We Visit Worlds', 'inLanguage' => 'en-GB', 'publisher' => array( '@id' => $org_id ) ),
	);
	if ( is_404() || ! $url ) {
		return $graph;
	}
	$page_type = 'WebPage';
	if ( is_page( 'about' ) ) {
		$page_type = 'AboutPage';
	} elseif ( is_page( 'contact' ) ) {
		$page_type = 'ContactPage';
	} elseif ( is_post_type_archive() ) {
		$page_type = 'CollectionPage';
	}
	$page = array( '@type' => $page_type, '@id' => $url . '#webpage', 'url' => $url, 'name' => wp_get_document_title(), 'description' => $desc, 'isPartOf' => array( '@id' => $site_id ), 'about' => array( '@id' => $org_id ), 'inLanguage' => 'en-GB' );
	$graph[] = $page;

	/* Breadcrumbs for inner pages. */
	if ( ! is_front_page() ) {
		$crumbs = array( array( 'Home', $home ) );
		if ( is_singular( 'case' ) ) {
			$crumbs[] = array( ucfirst( wvw_opt( 'work_title', 'our work' ) ), get_post_type_archive_link( 'case' ) );
		} elseif ( is_singular( 'trend' ) ) {
			$crumbs[] = array( ucfirst( wvw_opt( 'trends_title', 'trends' ) ), get_post_type_archive_link( 'trend' ) );
		}
		$crumbs[] = array( is_post_type_archive() ? ucfirst( post_type_archive_title( '', false ) ) : ucfirst( wp_strip_all_tags( get_the_title() ) ), $url );
		$items = array();
		foreach ( $crumbs as $i => $c ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => $c[1] );
		}
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $items );
	}

	if ( is_singular( 'trend' ) ) {
		$post    = get_post();
		$article = array(
			'@type'            => 'BlogPosting',
			'headline'         => html_entity_decode( wp_strip_all_tags( get_the_title() ), ENT_QUOTES, 'UTF-8' ),
			'description'      => $desc,
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'author'           => array( '@id' => $org_id ),
			'publisher'        => array( '@id' => $org_id ),
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'articleSection'   => wvw_get( 'category' ),
			'wordCount'        => str_word_count( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) ),
			'inLanguage'       => 'en-GB',
		);
		if ( has_post_thumbnail() ) {
			$article['image'] = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
		}
		$cites = array();
		foreach ( wvw_rows( wvw_get( 'sources' ) ) as $r ) {
			$cites[] = array_filter( array( '@type' => 'CreativeWork', 'name' => $r[0], 'url' => isset( $r[1] ) && 0 === strpos( $r[1], 'http' ) ? $r[1] : null ) );
		}
		if ( $cites ) {
			$article['citation'] = $cites;
		}
		$graph[] = $article;
	} elseif ( is_singular( 'case' ) ) {
		$work = array(
			'@type'       => 'CreativeWork',
			'name'        => wvw_title_case( get_the_title() ),
			'description' => $desc,
			'creator'     => array( '@id' => $org_id ),
			'url'         => $url,
			'genre'       => 'Tourism marketing case study',
			'inLanguage'  => 'en-GB',
		);
		if ( wvw_get( 'client' ) ) {
			$work['sponsor'] = array( '@type' => 'Organization', 'name' => wvw_get( 'client' ) );
		}
		if ( wvw_get( 'year' ) ) {
			$work['dateCreated'] = wvw_get( 'year' );
		}
		if ( wvw_get( 'country' ) ) {
			$work['spatialCoverage'] = wvw_get( 'country' );
		}
		if ( wvw_get( 'award' ) ) {
			$work['award'] = wvw_get( 'award' );
		}
		if ( has_post_thumbnail() ) {
			$work['image'] = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
		}
		$graph[] = $work;
	} elseif ( is_page( 'services' ) ) {
		$list = array();
		for ( $i = 1; $i <= 6; $i++ ) {
			if ( ! wvw_get( "svc{$i}_title" ) ) {
				continue;
			}
			$list[] = array( '@type' => 'ListItem', 'position' => count( $list ) + 1, 'item' => array(
				'@type'       => 'Service',
				'name'        => ucfirst( wvw_get( "svc{$i}_title" ) ),
				'description' => wvw_get( "svc{$i}_long" ),
				'serviceType' => wvw_get( "svc{$i}_short" ),
				'provider'    => array( '@id' => $org_id ),
				'areaServed'  => $org['areaServed'],
			) );
		}
		$graph[] = array( '@type' => 'ItemList', 'name' => 'Services', 'itemListElement' => $list );
	} elseif ( is_page( 'about' ) ) {
		$people = array();
		foreach ( get_posts( array( 'post_type' => 'team', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) ) as $m ) {
			$people[] = array_filter( array( '@type' => 'Person', 'name' => get_the_title( $m ), 'jobTitle' => wvw_get( 'role', $m->ID ), 'workLocation' => wvw_get( 'city', $m->ID ) ? array( '@type' => 'Place', 'name' => wvw_get( 'city', $m->ID ) ) : null, 'worksFor' => array( '@id' => $org_id ) ) );
		}
		if ( $people ) {
			$graph[] = array( '@type' => 'Organization', '@id' => $org_id, 'employee' => $people );
		}
	}
	return $graph;
}

/* Social icons (footer). Each icon appears only when its URL is filled in WVW › Definições. */
function wvw_social_icons() {
	$nets = array(
		'linkedin_url'  => array( 'LinkedIn', '<path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9.5h4V21H3zM9.5 9.5h3.8v1.6h.06c.53-1 1.83-2.06 3.77-2.06 4.03 0 4.77 2.65 4.77 6.1V21h-4v-5.2c0-1.24-.02-2.84-1.73-2.84-1.73 0-2 1.35-2 2.75V21h-4z"/>' ),
		'instagram_url' => array( 'Instagram', '<path d="M12 7.2a4.8 4.8 0 1 0 0 9.6 4.8 4.8 0 0 0 0-9.6zm0 7.9a3.1 3.1 0 1 1 0-6.2 3.1 3.1 0 0 1 0 6.2zM17.1 5.8a1.1 1.1 0 1 0 0 2.2 1.1 1.1 0 0 0 0-2.2z"/><path d="M12 2.5c-2.6 0-2.9 0-3.9.06-1 .05-1.7.2-2.3.45a4.7 4.7 0 0 0-1.7 1.1 4.7 4.7 0 0 0-1.1 1.7c-.25.6-.4 1.3-.45 2.3C2.5 9.1 2.5 9.4 2.5 12s0 2.9.06 3.9c.05 1 .2 1.7.45 2.3.26.65.6 1.2 1.1 1.7.5.5 1.05.84 1.7 1.1.6.25 1.3.4 2.3.45 1 .05 1.3.06 3.9.06s2.9 0 3.9-.06c1-.05 1.7-.2 2.3-.45a4.7 4.7 0 0 0 1.7-1.1c.5-.5.84-1.05 1.1-1.7.25-.6.4-1.3.45-2.3.05-1 .06-1.3.06-3.9s0-2.9-.06-3.9c-.05-1-.2-1.7-.45-2.3a4.7 4.7 0 0 0-1.1-1.7 4.7 4.7 0 0 0-1.7-1.1c-.6-.25-1.3-.4-2.3-.45-1-.05-1.3-.06-3.9-.06zm0 1.7c2.55 0 2.85 0 3.86.06.93.04 1.44.2 1.78.33.45.17.77.38 1.1.72.34.33.55.65.72 1.1.13.34.29.85.33 1.78.05 1 .06 1.3.06 3.86s0 2.85-.06 3.86c-.04.93-.2 1.44-.33 1.78-.17.45-.38.77-.72 1.1-.33.34-.65.55-1.1.72-.34.13-.85.29-1.78.33-1 .05-1.3.06-3.86.06s-2.85 0-3.86-.06c-.93-.04-1.44-.2-1.78-.33a2.97 2.97 0 0 1-1.1-.72 2.97 2.97 0 0 1-.72-1.1c-.13-.34-.29-.85-.33-1.78C4.2 14.85 4.2 14.55 4.2 12s0-2.85.06-3.86c.04-.93.2-1.44.33-1.78.17-.45.38-.77.72-1.1.33-.34.65-.55 1.1-.72.34-.13.85-.29 1.78-.33C9.15 4.2 9.45 4.2 12 4.2z"/>' ),
	);
	$out = '';
	foreach ( $nets as $key => $n ) {
		$url = wvw_opt( $key );
		if ( $url ) {
			$out .= '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" aria-label="We Visit Worlds on ' . esc_attr( $n[0] ) . '"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' . $n[1] . '</svg></a>';
		}
	}
	return $out ? '<div class="social">' . $out . '</div>' : '';
}

/* Favicon fallback when no Site Icon is set in Appearance › Customise. */
add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 fill=%27%230A0A0A%27/%3E%3Ctext x=%2732%27 y=%2746%27 font-family=%27Arial Black,Arial%27 font-weight=%27900%27 font-size=%2738%27 fill=%27white%27 text-anchor=%27middle%27%3EW%3C/text%3E%3C/svg%3E">' . "\n";
	}
} );

/* Archive titles: no "Archives:" prefix. */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );
