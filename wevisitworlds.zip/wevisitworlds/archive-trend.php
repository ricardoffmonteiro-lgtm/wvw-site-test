<?php
defined( 'ABSPATH' ) || exit;
get_header();
$all  = array();
while ( have_posts() ) {
	the_post();
	$all[] = get_post();
}
$cats = array_values( array_unique( array_filter( array_map( function ( $p ) { return wvw_get( 'category', $p->ID ); }, $all ) ) ) );
$feat = $all[0] ?? null;
?>
<section class="page-title"><div class="wrap"><h1 class="h1 rv"><?php echo esc_html( wvw_opt( 'trends_title', 'trends' ) ); ?></h1><p class="lead rv"><?php echo esc_html( wvw_opt( 'trends_lead' ) ); ?></p></div></section>
<?php if ( count( $cats ) > 1 ) : ?>
<section style="border-top:1px solid var(--line);border-bottom:1px solid var(--line)"><div class="wrap chips-scroll" role="group" aria-label="Filter by topic" style="display:flex;flex-wrap:wrap;gap:10px;padding-top:24px;padding-bottom:24px" data-filter="cat">
	<button class="chip" data-v="all" aria-pressed="true">All</button>
	<?php foreach ( $cats as $c ) : ?><button class="chip" data-v="<?php echo esc_attr( $c ); ?>" aria-pressed="false"><?php echo esc_html( $c ); ?></button><?php endforeach; ?>
</div></section>
<?php endif; ?>
<?php if ( $feat ) : ?>
<section style="padding:56px 0 32px" id="featWrap"><div class="wrap">
	<a class="card split-r" href="<?php echo esc_url( get_permalink( $feat ) ); ?>" data-cat="<?php echo esc_attr( wvw_get( 'category', $feat->ID ) ); ?>" id="featured">
		<div class="img" style="height:440px"><?php echo wvw_trend_cover( $feat->ID, 0 ); ?></div>
		<div class="stack" style="gap:18px"><p class="eyebrow">Latest · <?php echo esc_html( wvw_get( 'category', $feat->ID ) ); ?> · <?php echo esc_html( get_the_date( 'j M Y', $feat ) ); ?></p><p class="t" style="font-size:clamp(30px,3.2vw,44px)"><?php echo esc_html( get_the_title( $feat ) ); ?></p><p class="p"><?php echo esc_html( get_the_excerpt( $feat ) ); ?></p><span class="arr">Read article <?php echo wvw_icon( 'arr' ); ?></span></div>
	</a>
</div></section>
<?php endif; ?>
<section style="padding:32px 0 72px"><div class="wrap">
	<div class="grid3" id="list"><?php foreach ( array_slice( $all, 1 ) as $i => $p ) { echo wvw_trend_card( $p, 250, $i ); } // phpcs:ignore ?></div>
	<div class="more-wrap"><button class="btn btn-o" id="more" type="button">Load more articles</button></div>
</div></section>
<?php
get_footer();
