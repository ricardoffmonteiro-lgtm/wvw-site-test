<?php
defined( 'ABSPATH' ) || exit;
$email   = wvw_opt( 'contact_email', 'hello@wevisitworlds.com' );
$phone   = wvw_opt( 'phone' );
$offices = wvw_rows( wvw_opt( 'offices', "Porto | Headquarters\nLisbon | Office\nMadrid | Office" ) );
$pdf     = wvw_opt( 'credentials_pdf' );
?>
</main>

<footer>
	<div class="wrap">
		<div class="big">
			<h2><span class="a"><?php echo esc_html( wvw_opt( 'footer_a', 'do you want to be' ) ); ?></span><span class="b"><?php echo esc_html( wvw_opt( 'footer_b', 'top of mind?' ) ); ?></span></h2>
			<a class="btn btn-w" href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>" style="min-height:64px;font-size:18px;padding:0 36px"><?php echo esc_html( wvw_opt( 'footer_cta', 'Get started' ) ); ?> <?php echo wvw_icon( 'arr' ); ?></a>
		</div>
		<div class="cols">
			<div><p class="h">CONTACT</p>
				<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
				<?php if ( $phone ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><?php endif; ?>
				<a href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>">Send us a brief</a>
				<?php if ( wvw_opt( 'linkedin_url' ) ) : ?><a href="<?php echo esc_url( wvw_opt( 'linkedin_url' ) ); ?>" rel="noopener">LinkedIn</a><?php endif; ?>
				<?php if ( wvw_opt( 'instagram_url' ) ) : ?><a href="<?php echo esc_url( wvw_opt( 'instagram_url' ) ); ?>" rel="noopener">Instagram</a><?php endif; ?>
			</div>
			<div><p class="h">OFFICES</p><?php foreach ( $offices as $o ) : ?><span><?php echo esc_html( $o[0] ); ?></span><?php endforeach; ?></div>
			<div><p class="h">SITE</p>
				<a href="<?php echo esc_url( wvw_page_url( 'about' ) ); ?>">About</a>
				<a href="<?php echo esc_url( get_post_type_archive_link( 'case' ) ); ?>">Our work</a>
				<a href="<?php echo esc_url( wvw_page_url( 'services' ) ); ?>">Services</a>
				<a href="<?php echo esc_url( get_post_type_archive_link( 'trend' ) ); ?>">Trends</a>
			</div>
			<div><p class="h">LEGAL</p>
				<a href="<?php echo esc_url( wvw_page_url( 'privacy-cookies' ) ); ?>">Privacy &amp; cookies</a>
				<a href="<?php echo esc_url( wvw_page_url( 'privacy-cookies' ) ); ?>#accessibility">Accessibility</a>
				<?php if ( wvw_opt( 'complaints_url' ) ) : ?><a href="<?php echo esc_url( wvw_opt( 'complaints_url' ) ); ?>" rel="noopener">Livro de Reclamações</a><?php endif; ?>
				<?php if ( $pdf ) : ?><a href="<?php echo esc_url( wp_get_attachment_url( $pdf ) ); ?>" target="_blank" rel="noopener">Credentials (PDF)</a><?php endif; ?>
			</div>
		</div>
		<div class="legal"><span>© <?php echo esc_html( gmdate( 'Y' ) . ' ' . wvw_opt( 'legal_name', 'We Visit Worlds, Lda' ) ); ?><?php echo wvw_opt( 'legal_details' ) ? ' · ' . esc_html( wvw_opt( 'legal_details' ) ) : ''; ?></span><span><?php echo esc_html( implode( ' · ', array_column( $offices, 0 ) ) ); ?></span></div>
	</div>
</footer>

<?php if ( is_singular( 'case' ) ) : ?>
<div class="sticky-cta" id="stickyCta" data-on="1"><p><?php echo esc_html( wvw_opt( 'case_cta', 'A campaign like this for your destination?' ) ); ?></p><a class="btn" href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>">Talk to us</a></div>
<?php endif; ?>
<div class="lightbox" id="lightbox" role="dialog" aria-modal="true" aria-label="Image viewer"><button id="lbClose" aria-label="Close image"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button><img id="lbImg" src="data:image/gif;base64,R0lGODlhAQABAAAAACw=" alt=""></div>
<?php wp_footer(); ?>
</body>
</html>
