<?php
defined( 'ABSPATH' ) || exit;
get_header();
the_post();
$id    = get_the_ID();
$all   = get_posts( array( 'post_type' => 'case', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC', 'fields' => 'ids' ) );
$i     = array_search( $id, $all, true );
$prev  = count( $all ) > 1 ? $all[ ( $i - 1 + count( $all ) ) % count( $all ) ] : 0;
$next  = count( $all ) > 1 ? $all[ ( $i + 1 ) % count( $all ) ] : 0;
$facts = array_filter( array(
	'CLIENT'   => wvw_get( 'client' ),
	'MARKET'   => wvw_get( 'country' ),
	'YEAR'     => wvw_get( 'year' ),
	'CHANNELS' => wvw_get( 'channels' ),
	'AWARD'    => wvw_get( 'award' ),
) );
$kpis    = wvw_kpis( wvw_get( 'kpis' ) );
$gallery = wvw_ids( wvw_get( 'gallery' ) );
?>
<div class="wrap" style="padding-top:24px"><a class="link back" href="<?php echo esc_url( get_post_type_archive_link( 'case' ) ); ?>"><?php echo wvw_icon( 'larr' ); ?> All projects</a></div>
<section style="padding:24px 0 56px"><div class="wrap" style="display:grid;grid-template-columns:minmax(0,5fr) minmax(0,7fr);gap:64px;align-items:end" data-split>
	<div class="stack" style="padding-bottom:24px"><p class="eyebrow">Case study · <?php echo esc_html( wvw_get( 'market_label' ) ); ?></p><h1 class="h1 rv" style="font-size:clamp(40px,4.6vw,76px)"><?php the_title(); ?></h1><p class="lead"><?php echo esc_html( wvw_get( 'lead' ) ); ?></p></div>
	<div class="card"><div class="img kv"><?php echo wvw_img( get_post_thumbnail_id(), 'large', '', false ); ?></div></div>
</div></section>
<?php if ( $facts ) : ?>
<section class="mist" style="padding:36px 0"><div class="wrap"><dl class="facts" style="margin:0;--n:<?php echo count( $facts ); ?>"><?php foreach ( $facts as $k => $v ) : ?><div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $v ); ?></dd></div><?php endforeach; ?></dl></div></section>
<?php endif; ?>
<section class="sec"><div class="wrap split"><h2 class="h2 rv">the idea</h2><div class="case-body"><?php the_content(); ?></div></div></section>
<?php if ( $kpis ) : ?>
<section class="sec dark"><div class="wrap stack" style="gap:56px">
	<h2 class="h2 rv">the results</h2>
	<?php echo wvw_kpi_html( $kpis, 4 ); // phpcs:ignore ?>
	<?php if ( wvw_get( 'presence' ) ) : ?><p class="lead" style="max-width:860px;border-top:1px solid #404040;padding-top:28px"><?php echo esc_html( wvw_get( 'presence' ) ); ?></p><?php endif; ?>
</div></section>
<?php endif; ?>
<?php if ( $gallery ) : ?>
<section style="padding:72px 0 40px"><div class="wrap gallery">
	<?php foreach ( array_slice( $gallery, 0, 3 ) as $g ) : $alt = get_post_meta( $g, '_wp_attachment_image_alt', true ); ?>
		<button data-lb="<?php echo esc_url( wp_get_attachment_image_url( $g, 'full' ) ); ?>" aria-label="Enlarge: <?php echo esc_attr( $alt ); ?>"><?php echo wvw_img( $g, 'medium_large' ); ?></button>
	<?php endforeach; ?>
</div></section>
<?php endif; ?>
<?php $svc = wvw_list( wvw_get( 'services' ) ); if ( $svc ) : ?>
<section style="padding:<?php echo $kpis ? '40px' : '0'; ?> 0 72px"><div class="wrap split">
	<p class="eyebrow">What we did</p>
	<div style="display:flex;flex-wrap:wrap;gap:8px"><?php foreach ( $svc as $s ) : ?><span class="tag" style="min-height:44px;font-size:16px;padding:0 18px"><?php echo esc_html( $s ); ?></span><?php endforeach; ?></div>
</div></section>
<?php endif; ?>
<?php if ( $prev && $next ) : ?>
<section><div class="wrap pn"><a href="<?php echo esc_url( get_permalink( $prev ) ); ?>"><span class="eyebrow">Previous</span><b><?php echo esc_html( get_the_title( $prev ) ); ?></b></a><a href="<?php echo esc_url( get_permalink( $next ) ); ?>"><span class="eyebrow">Next</span><b><?php echo esc_html( get_the_title( $next ) ); ?></b></a></div></section>
<?php endif; ?>
<section class="mist cta-band"><div class="wrap"><p><?php echo esc_html( wvw_opt( 'case_cta', 'A campaign like this for your destination?' ) ); ?></p><a class="btn" href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>">Talk to us <?php echo wvw_icon( 'arr' ); ?></a></div></section>
<?php
get_footer();
