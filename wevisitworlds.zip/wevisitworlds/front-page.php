<?php
defined( 'ABSPATH' ) || exit;
get_header();
$pid      = get_queried_object_id();
$f        = function ( $k, $d = '' ) use ( $pid ) { return wvw_get( $k, $pid, $d ); };
$title    = $f( 'hero_title', 'we put destinations top of mind.' );
$featured = (int) $f( 'featured_case' );
$services = get_page_by_path( 'services' );
$cases    = get_posts( array( 'post_type' => 'case', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
$trends   = get_posts( array( 'post_type' => 'trend', 'numberposts' => 3 ) );
$recog_c  = (int) $f( 'recog_link_case' );
?>
<section class="hero">
	<div class="txt">
		<p class="eyebrow" style="color:#D4D4D4"><?php echo esc_html( $f( 'hero_eyebrow' ) ); ?></p>
		<h1><?php
		$words = explode( ' ', $title );
		foreach ( $words as $i => $w ) {
			printf( '<span class="w" style="animation-delay:%dms">%s</span>%s', $i * 70, esc_html( $w ), $i < count( $words ) - 1 ? ' ' : '' );
		}
		?></h1>
		<p class="sub"><?php echo esc_html( $f( 'hero_sub' ) ); ?></p>
		<div class="ctas">
			<a class="btn btn-w" href="<?php echo esc_url( wvw_page_url( 'contact' ) ); ?>"><?php echo esc_html( $f( 'hero_cta1', 'Talk to us' ) ); ?> <?php echo wvw_icon( 'arr' ); ?></a>
			<a class="btn btn-ow" href="<?php echo esc_url( get_post_type_archive_link( 'case' ) ); ?>"><?php echo esc_html( $f( 'hero_cta2', 'See our work' ) ); ?></a>
		</div>
		<a class="scroll-cue" href="#clients" data-scroll><i aria-hidden="true"></i><?php echo esc_html( implode( ' · ', array_column( wvw_rows( wvw_opt( 'offices' ) ), 0 ) ) ); ?></a>
	</div>
	<div class="media"><?php echo wvw_img( $f( 'hero_image' ), 'full', '', false ); ?></div>
</section>

<section id="clients" style="border-bottom:1px solid var(--line)">
	<?php $logo_ids = wvw_ids( $f( 'client_logos' ) ); ?>
	<div class="wrap clients">
		<p class="eyebrow"><?php echo esc_html( $f( 'clients_label', 'Trusted by' ) ); ?></p>
		<div class="clients-row">
			<div class="marquee" role="region" aria-label="Clients">
				<div class="marquee-track">
					<?php for ( $pass = 0; $pass < 2; $pass++ ) : foreach ( $logo_ids as $lid ) : ?>
						<div class="cl-box"<?php echo $pass ? ' aria-hidden="true"' : ''; ?>><?php echo wvw_img( $lid, 'medium', '', true, $pass ? '' : null ); // phpcs:ignore ?></div>
					<?php endforeach; endfor; ?>
				</div>
			</div>
			<?php if ( $f( 'award_title' ) ) : ?>
				<div class="cl-box cl-award"><?php echo $f( 'award_logo' ) ? wvw_img( $f( 'award_logo' ), 'medium', '', true, '' ) : wvw_icon( 'medal' ); // phpcs:ignore ?><p><b><?php echo esc_html( $f( 'award_title' ) ); ?></b><?php echo implode( '<br>', array_map( 'esc_html', array_map( 'trim', explode( '|', $f( 'award_sub' ) ) ) ) ); // phpcs:ignore ?></p></div>
			<?php endif; ?>
		</div>
	</div>
</section>

<?php if ( $featured && get_post( $featured ) ) : ?>
<section class="sec">
	<div class="wrap split-r">
		<a class="card rv" href="<?php echo esc_url( get_permalink( $featured ) ); ?>" aria-label="<?php echo esc_attr( get_the_title( $featured ) ); ?> case study"><div class="img kv"><?php echo wvw_img( get_post_thumbnail_id( $featured ), 'large' ); ?></div></a>
		<div class="stack">
			<p class="eyebrow">Featured case · <?php echo esc_html( wvw_get( 'market_label', $featured ) ); ?></p>
			<h2 class="h2 rv"><?php echo esc_html( get_the_title( $featured ) ); ?></h2>
			<p class="p"><?php echo esc_html( wvw_get( 'summary', $featured ) ); ?></p>
			<?php
			$k = array_map( function ( $x ) {
				$x['desc'] = trim( ucfirst( strtolower( $x['label'] ) ) . ' ' . $x['desc'] );
				$x['label'] = '';
				return $x;
			}, wvw_kpis( wvw_get( 'kpis', $featured ) ) );
			if ( $k ) {
				echo wvw_kpi_html( $k, 2 ); // phpcs:ignore
			}
			?>
			<a class="btn btn-o" href="<?php echo esc_url( get_permalink( $featured ) ); ?>" style="align-self:flex-start;margin-top:8px">View case study <?php echo wvw_icon( 'arr' ); ?></a>
		</div>
	</div>
</section>
<?php endif; ?>

<section class="sec dark">
	<div class="wrap stack" style="gap:48px">
		<div class="head-row"><h2 class="h2 rv"><?php echo esc_html( $f( 'markets_title' ) ); ?></h2><p class="p" style="max-width:440px"><?php echo esc_html( $f( 'markets_text' ) ); ?></p></div>
		<div class="markets">
			<?php for ( $i = 1; $i <= 3; $i++ ) : if ( ! $f( "market{$i}_name" ) ) { continue; } ?>
				<div class="market rv"><b><?php echo esc_html( $f( "market{$i}_name" ) ); ?></b><span><?php echo esc_html( $f( "market{$i}_sub" ) ); ?></span></div>
			<?php endfor; ?>
		</div>
	</div>
</section>

<?php if ( $services ) : ?>
<section class="sec">
	<div class="wrap" style="display:grid;grid-template-columns:minmax(0,4fr) minmax(0,8fr);gap:64px" data-split>
		<div class="stack"><h2 class="h2 rv">services</h2><p class="p"><?php echo esc_html( $f( 'services_text' ) ); ?></p><a class="link" href="<?php echo esc_url( get_permalink( $services ) ); ?>">How we work <?php echo wvw_icon( 'arr' ); ?></a></div>
		<div>
			<?php for ( $i = 1; $i <= 6; $i++ ) : $st = wvw_get( "svc{$i}_title", $services->ID ); if ( ! $st ) { continue; } ?>
				<a class="srow" href="<?php echo esc_url( get_permalink( $services ) . '#svc-0' . $i ); ?>"><span class="n">0<?php echo (int) $i; ?></span><span class="t"><?php echo esc_html( $st ); ?></span><span class="d"><?php echo esc_html( wvw_get( "svc{$i}_short", $services->ID ) ); ?></span><?php echo wvw_icon( 'arr' ); ?></a>
			<?php endfor; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $cases ) : ?>
<section style="padding-bottom:72px">
	<div class="wrap head-row" style="margin-bottom:40px"><h2 class="h2 rv">our work</h2><div class="car-ctrl"><button data-car="-1" aria-label="Previous projects"><?php echo wvw_icon( 'larr' ); ?></button><button data-car="1" aria-label="Next projects"><?php echo wvw_icon( 'arr' ); ?></button></div></div>
	<div class="carousel" id="car" tabindex="0" aria-label="Projects"><?php foreach ( $cases as $c ) { echo wvw_case_card( $c, false, false ); } // phpcs:ignore ?></div>
	<div class="wrap"><div class="progress"><i id="carBar"></i></div><p style="margin-top:28px"><a class="link" href="<?php echo esc_url( get_post_type_archive_link( 'case' ) ); ?>">See all projects <?php echo wvw_icon( 'arr' ); ?></a></p></div>
</section>
<?php endif; ?>

<?php if ( $f( 'recog_title' ) ) : ?>
<section class="sec mist">
	<div class="wrap recog">
		<div class="stack">
			<p class="eyebrow">Recognition</p>
			<h2 class="h2 rv"><?php echo esc_html( $f( 'recog_title' ) ); ?></h2>
			<p class="p"><?php echo esc_html( $f( 'recog_text' ) ); ?></p>
			<?php if ( $recog_c ) : ?><a class="link" href="<?php echo esc_url( get_permalink( $recog_c ) ); ?>">See the campaign <?php echo wvw_icon( 'arr' ); ?></a><?php endif; ?>
		</div>
		<div class="card"><div class="img"><?php echo wvw_img( $f( 'recog_image' ), 'large' ); ?></div></div>
	</div>
</section>
<?php endif; ?>

<section class="sec">
	<div class="wrap split-r">
		<div class="card team-photo"><div class="img"><?php echo wvw_img( $f( 'about_image' ), 'large' ); ?></div></div>
		<div class="stack"><p class="eyebrow">About</p><h2 class="h2 rv"><?php echo esc_html( $f( 'about_title' ) ); ?></h2><p class="p"><?php echo esc_html( $f( 'about_text' ) ); ?></p><a class="link" href="<?php echo esc_url( wvw_page_url( 'about' ) ); ?>">Meet the team <?php echo wvw_icon( 'arr' ); ?></a></div>
	</div>
</section>

<?php if ( $trends ) : ?>
<section style="padding-bottom:72px">
	<div class="wrap stack" style="gap:40px">
		<div class="head-row"><h2 class="h2 rv">latest trends</h2><a class="link" href="<?php echo esc_url( get_post_type_archive_link( 'trend' ) ); ?>">All trends <?php echo wvw_icon( 'arr' ); ?></a></div>
		<div class="grid3"><?php foreach ( $trends as $i => $t ) { echo wvw_trend_card( $t, 240, $i ); } // phpcs:ignore ?></div>
	</div>
</section>
<?php endif; ?>
<?php
get_footer();
