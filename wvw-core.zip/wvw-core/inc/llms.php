<?php
defined( 'ABSPATH' ) || exit;

/**
 * /llms.txt - plain-text summary of the site for AI assistants and AI search
 * (ChatGPT, Claude, Perplexity, Google AI). Built automatically from the content
 * edited in the backoffice, so it never needs manual updates.
 */
add_action( 'init', function () {
	add_rewrite_rule( '^llms\.txt$', 'index.php?wvw_llms=1', 'top' );
} );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'wvw_llms';
	return $v;
} );

/* Point crawlers to it from robots.txt. */
add_filter( 'robots_txt', function ( $out ) {
	return $out . "\n# Summary for AI assistants: " . home_url( '/llms.txt' ) . "\n";
} );

function wvw_llms_build() {
	$page = function ( $slug ) {
		$p = get_page_by_path( $slug );
		return $p ? $p->ID : 0;
	};
	$clean = function ( $t ) {
		return trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( (string) $t ) ) ) );
	};
	$home  = (int) get_option( 'page_on_front' );
	$out   = array();
	$out[] = '# We Visit Worlds';
	$out[] = '';
	$out[] = '> ' . $clean( wvw_opt( 'seo_description' ) );
	$out[] = '';
	$out[] = $clean( wvw_get( 'hero_sub', $home ) );
	$out[] = '';

	$out[] = '## Company';
	$out[] = '- Legal name: ' . wvw_opt( 'legal_name', 'We Visit Worlds, Lda' );
	$offices = wvw_rows( wvw_opt( 'offices' ) );
	if ( $offices ) {
		$out[] = '- Offices: ' . implode( ', ', array_map( function ( $o ) {
			return $o[0] . ( ! empty( $o[1] ) ? ' (' . $o[1] . ')' : '' );
		}, $offices ) );
	}
	$markets = array();
	for ( $i = 1; $i <= 3; $i++ ) {
		if ( wvw_get( "market{$i}_name", $home ) ) {
			$markets[] = wvw_get( "market{$i}_name", $home ) . ( wvw_get( "market{$i}_sub", $home ) ? ' (' . wvw_get( "market{$i}_sub", $home ) . ')' : '' );
		}
	}
	if ( $markets ) {
		$out[] = '- Markets: ' . implode( '; ', $markets );
	}
	$awards = array_unique( array_filter( array_map( function ( $c ) {
		return wvw_get( 'award', $c->ID ) ? wvw_get( 'award', $c->ID ) . ' (' . wvw_title_case( get_the_title( $c ) ) . ')' : '';
	}, get_posts( array( 'post_type' => 'case', 'numberposts' => -1 ) ) ) ) );
	if ( $awards ) {
		$out[] = '- Recognition: ' . implode( '; ', $awards );
	}
	$out[] = '- Contact: ' . wvw_opt( 'contact_email' ) . ' - brief form: ' . get_permalink( $page( 'contact' ) );
	foreach ( array( 'linkedin_url' => 'LinkedIn', 'instagram_url' => 'Instagram' ) as $k => $n ) {
		if ( wvw_opt( $k ) ) {
			$out[] = '- ' . $n . ': ' . wvw_opt( $k );
		}
	}
	$out[] = '';

	$sid = $page( 'services' );
	if ( $sid ) {
		$out[] = '## Services';
		$out[] = '';
		$out[] = $clean( wvw_get( 'intro', $sid ) );
		$out[] = '';
		for ( $i = 1; $i <= 6; $i++ ) {
			if ( wvw_get( "svc{$i}_title", $sid ) ) {
				$out[] = '- ' . ucfirst( wvw_get( "svc{$i}_title", $sid ) ) . ': ' . $clean( wvw_get( "svc{$i}_long", $sid ) );
			}
		}
		$out[] = '- Details: ' . get_permalink( $sid );
		$out[] = '';
	}

	$cases = get_posts( array( 'post_type' => 'case', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $cases ) {
		$out[] = '## Case studies';
		$out[] = '';
		foreach ( $cases as $c ) {
			$facts = array_filter( array( wvw_get( 'client', $c->ID ), wvw_get( 'market_label', $c->ID ), wvw_get( 'year', $c->ID ), wvw_get( 'award', $c->ID ) ) );
			$out[] = '- [' . wvw_title_case( get_the_title( $c ) ) . '](' . get_permalink( $c ) . '): ' . $clean( wvw_get( 'summary', $c->ID ) ) . ( $facts ? ' (' . implode( ' · ', $facts ) . ')' : '' );
		}
		$out[] = '';
	}

	$team = get_posts( array( 'post_type' => 'team', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	if ( $team ) {
		$out[] = '## Team';
		$out[] = '';
		foreach ( $team as $m ) {
			$bits  = array_filter( array( wvw_get( 'role', $m->ID ), wvw_get( 'city', $m->ID ) ) );
			$out[] = '- ' . get_the_title( $m ) . ( $bits ? ', ' . implode( ', ', $bits ) : '' );
		}
		$out[] = '';
	}

	$trends = get_posts( array( 'post_type' => 'trend', 'numberposts' => 20 ) );
	if ( $trends ) {
		$out[] = '## Trends (tourism insights)';
		$out[] = '';
		foreach ( $trends as $t ) {
			$out[] = '- [' . html_entity_decode( get_the_title( $t ), ENT_QUOTES, 'UTF-8' ) . '](' . get_permalink( $t ) . ') - ' . get_the_date( 'Y-m-d', $t ) . ': ' . $clean( get_the_excerpt( $t ) );
		}
		$out[] = '';
	}

	$out[] = '## Pages';
	$out[] = '';
	foreach ( array( 'about' => 'About', 'services' => 'Services', 'contact' => 'Contact', 'privacy-cookies' => 'Privacy & cookies' ) as $slug => $label ) {
		if ( $page( $slug ) ) {
			$out[] = '- [' . $label . '](' . get_permalink( $page( $slug ) ) . ')';
		}
	}
	$out[] = '- [Our work](' . get_post_type_archive_link( 'case' ) . ')';
	$out[] = '- [Trends](' . get_post_type_archive_link( 'trend' ) . ')';

	return implode( "\n", $out ) . "\n";
}

add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'wvw_llms' ) ) {
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'X-Robots-Tag: noindex' );
	echo wvw_llms_build(); // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
} );

/* No trailing-slash redirect for /llms.txt. */
add_filter( 'redirect_canonical', function ( $redirect ) {
	return get_query_var( 'wvw_llms' ) ? false : $redirect;
} );

/* Also keep a real file in the site root: some servers (nginx) serve .txt files directly without WordPress. Refreshed whenever content is saved. */
function wvw_llms_write() {
	$file = ABSPATH . 'llms.txt';
	if ( ( file_exists( $file ) && is_writable( $file ) ) || ( ! file_exists( $file ) && is_writable( ABSPATH ) ) ) {
		file_put_contents( $file, wvw_llms_build() ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
}
add_action( 'save_post', function ( $id, $post ) {
	if ( in_array( $post->post_type, array( 'page', 'case', 'trend', 'team' ), true ) && 'publish' === $post->post_status ) {
		wvw_llms_write();
	}
}, 20, 2 );
add_action( 'update_option_wvw_settings', 'wvw_llms_write' );
/* Right after the installer the clean URLs are not loaded yet in that request: write the file on the next page load. */
add_action( 'wvw_after_seed', function () {
	update_option( 'wvw_llms_pending', 1, false );
} );
add_action( 'wp_loaded', function () {
	if ( get_option( 'wvw_llms_pending' ) ) {
		delete_option( 'wvw_llms_pending' );
		wvw_llms_write();
	}
} );
