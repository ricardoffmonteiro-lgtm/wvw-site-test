<?php
defined( 'ABSPATH' ) || exit;

function wvw_register_post_types() {
	register_post_type( 'case', array(
		'labels'        => array(
			'name'          => 'Cases',
			'singular_name' => 'Case',
			'add_new'       => 'Adicionar case',
			'add_new_item'  => 'Adicionar novo case',
			'edit_item'     => 'Editar case',
			'all_items'     => 'Todos os cases',
		),
		'public'        => true,
		'has_archive'   => 'work',
		'rewrite'       => array( 'slug' => 'work', 'with_front' => false ),
		'menu_icon'     => 'dashicons-portfolio',
		'menu_position' => 5,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'page-attributes', 'revisions' ),
		'show_in_rest'  => true,
	) );

	register_post_type( 'trend', array(
		'labels'        => array(
			'name'          => 'Trends',
			'singular_name' => 'Artigo',
			'add_new'       => 'Adicionar artigo',
			'add_new_item'  => 'Adicionar novo artigo',
			'edit_item'     => 'Editar artigo',
			'all_items'     => 'Todos os artigos',
		),
		'public'        => true,
		'has_archive'   => 'trends',
		'rewrite'       => array( 'slug' => 'trends', 'with_front' => false ),
		'menu_icon'     => 'dashicons-chart-line',
		'menu_position' => 6,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
		'show_in_rest'  => true,
	) );

	register_post_type( 'team', array(
		'labels'              => array(
			'name'          => 'Equipa',
			'singular_name' => 'Pessoa',
			'add_new'       => 'Adicionar pessoa',
			'add_new_item'  => 'Adicionar pessoa',
			'edit_item'     => 'Editar pessoa',
			'all_items'     => 'Toda a equipa',
		),
		'public'              => false,
		'show_ui'             => true,
		'menu_icon'           => 'dashicons-groups',
		'menu_position'       => 7,
		'supports'            => array( 'title', 'thumbnail', 'page-attributes' ),
		'exclude_from_search' => true,
	) );

	register_post_type( 'brief', array(
		'labels'              => array(
			'name'          => 'Briefs recebidos',
			'singular_name' => 'Brief',
			'edit_item'     => 'Ver brief',
			'all_items'     => 'Briefs recebidos',
		),
		'public'              => false,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_icon'           => 'dashicons-email-alt',
		'menu_position'       => 8,
		'supports'            => array( 'title' ),
		'capabilities'        => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'        => true,
		'exclude_from_search' => true,
	) );
}
add_action( 'init', 'wvw_register_post_types' );

/* Classic editor everywhere: simpler for the team, and fields sit right below the text. */
add_filter( 'use_block_editor_for_post', '__return_false' );
add_filter( 'use_block_editor_for_post_type', '__return_false' );

/* Show Cases and Team in their manual order. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_post_type_archive( 'case' ) ) {
		$q->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'DESC' ) );
		$q->set( 'posts_per_page', -1 );
	}
	if ( $q->is_post_type_archive( 'trend' ) ) {
		$q->set( 'posts_per_page', -1 );
	}
} );

/* Helpful admin columns. */
add_filter( 'manage_case_posts_columns', function ( $c ) {
	return array_slice( $c, 0, 2, true ) + array( 'wvw_market' => 'Mercado', 'menu_order' => 'Ordem' ) + $c;
} );
add_action( 'manage_case_posts_custom_column', function ( $col, $id ) {
	if ( 'wvw_market' === $col ) {
		echo esc_html( wvw_get( 'market_label', $id ) );
	}
	if ( 'menu_order' === $col ) {
		echo (int) get_post_field( 'menu_order', $id );
	}
}, 10, 2 );
add_filter( 'manage_brief_posts_columns', function ( $c ) {
	return array( 'cb' => $c['cb'], 'title' => 'Organização / nome', 'wvw_email' => 'Email', 'wvw_needs' => 'Pedido', 'date' => 'Recebido' );
} );
add_action( 'manage_brief_posts_custom_column', function ( $col, $id ) {
	if ( 'wvw_email' === $col ) {
		echo esc_html( get_post_meta( $id, '_wvw_brief_email', true ) );
	}
	if ( 'wvw_needs' === $col ) {
		echo esc_html( get_post_meta( $id, '_wvw_brief_needs', true ) );
	}
}, 10, 2 );
