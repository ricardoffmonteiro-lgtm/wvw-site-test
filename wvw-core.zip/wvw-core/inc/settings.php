<?php
defined( 'ABSPATH' ) || exit;

function wvw_settings_fields() {
	return array(
		'Contactos e empresa'   => array(
			'contact_email'  => array( 'Email público', 'email', 'Aparece no site e é o destino dos briefs, se o campo seguinte estiver vazio.' ),
			'brief_to'       => array( 'Enviar briefs para', 'email', 'Opcional. Pode ter vários emails separados por vírgulas.' ),
			'phone'          => array( 'Telefone', 'text', 'Vazio = não aparece.' ),
			'offices'        => array( 'Escritórios (um por linha)', 'textarea', 'Formato: Cidade | detalhe. Ex.: Porto | Headquarters' ),
			'legal_name'     => array( 'Nome legal', 'text', 'Ex.: We Visit Worlds, Lda' ),
			'legal_details'  => array( 'Dados legais (rodapé)', 'text', 'Ex.: NIF 000 000 000 · Rua…, Porto. Vazio = não aparece.' ),
			'complaints_url' => array( 'Livro de Reclamações (endereço)', 'url', 'Ex.: https://www.livroreclamacoes.pt' ),
			'linkedin_url'   => array( 'LinkedIn (endereço)', 'url', 'Vazio = não aparece.' ),
			'instagram_url'  => array( 'Instagram (endereço)', 'url', 'Vazio = não aparece.' ),
		),
		'Documentos'            => array(
			'credentials_pdf' => array( 'PDF de credenciais', 'file', 'Botão “Download credentials” na página Services e ligação no rodapé.' ),
		),
		'Textos gerais'         => array(
			'footer_a'       => array( 'Rodapé · linha pequena', 'text', '' ),
			'footer_b'       => array( 'Rodapé · linha grande', 'text', '' ),
			'footer_cta'     => array( 'Rodapé · botão', 'text', '' ),
			'work_title'     => array( 'Our work · título', 'text', '' ),
			'work_lead'      => array( 'Our work · frase', 'textarea', '' ),
			'trends_title'   => array( 'Trends · título', 'text', '' ),
			'trends_lead'    => array( 'Trends · frase', 'textarea', '' ),
			'case_cta'       => array( 'Frase de contacto no fim de cada case', 'text', '' ),
			'seo_description' => array( 'Descrição para Google (geral)', 'textarea', 'Até 160 caracteres. Os cases e artigos usam o seu próprio resumo.' ),
			'og_image'       => array( 'Imagem de partilha (geral)', 'image', '1200 × 630 px. Usada quando a página não tem imagem própria.' ),
		),
	);
}

add_action( 'admin_menu', function () {
	add_menu_page( 'WVW · Definições', 'WVW', 'manage_options', 'wvw-settings', 'wvw_settings_page', 'dashicons-admin-site-alt3', 3 );
} );

add_action( 'admin_init', function () {
	register_setting( 'wvw_settings', 'wvw_settings', array(
		'sanitize_callback' => function ( $in ) {
			$out = array();
			foreach ( wvw_settings_fields() as $group ) {
				foreach ( $group as $k => $f ) {
					$v = $in[ $k ] ?? '';
					switch ( $f[1] ) {
						case 'email':
							$out[ $k ] = implode( ',', array_filter( array_map( 'sanitize_email', explode( ',', $v ) ) ) );
							break;
						case 'url':
							$out[ $k ] = esc_url_raw( $v );
							break;
						case 'textarea':
							$out[ $k ] = sanitize_textarea_field( $v );
							break;
						case 'image':
						case 'file':
							$out[ $k ] = absint( $v ) ?: '';
							break;
						default:
							$out[ $k ] = sanitize_text_field( $v );
					}
				}
			}
			return $out;
		},
	) );
} );

function wvw_settings_page() {
	$o = get_option( 'wvw_settings', array() );
	echo '<div class="wrap wvw-settings"><h1>We Visit Worlds · Definições</h1>';
	if ( isset( $_GET['wvw_seeded'] ) ) {
		echo '<div class="notice notice-success"><p>Conteúdo inicial instalado.</p></div>';
	}
	echo '<form method="post" action="options.php">';
	settings_fields( 'wvw_settings' );
	foreach ( wvw_settings_fields() as $title => $group ) {
		echo '<h2>' . esc_html( $title ) . '</h2><table class="form-table" role="presentation">';
		foreach ( $group as $k => $f ) {
			$id = 'wvw_set_' . $k;
			$v  = $o[ $k ] ?? '';
			echo '<tr><th scope="row"><label for="' . esc_attr( $id ) . '">' . esc_html( $f[0] ) . '</label></th><td class="wvw-field">';
			$name = 'wvw_settings[' . $k . ']';
			if ( 'textarea' === $f[1] ) {
				printf( '<textarea id="%s" name="%s" rows="3" class="large-text">%s</textarea>', esc_attr( $id ), esc_attr( $name ), esc_textarea( $v ) );
			} elseif ( in_array( $f[1], array( 'image', 'file' ), true ) ) {
				printf( '<input type="hidden" id="%s" name="%s" value="%s" class="wvw-media-input">', esc_attr( $id ), esc_attr( $name ), esc_attr( $v ) );
				echo '<div class="wvw-media-preview">';
				if ( $v ) {
					echo 'file' === $f[1] ? '<span class="wvw-thumb wvw-file">' . esc_html( basename( (string) get_attached_file( $v ) ) ) . '</span>' : '<span class="wvw-thumb">' . wp_get_attachment_image( $v, 'thumbnail' ) . '</span>';
				}
				echo '</div>';
				printf( '<button type="button" class="button wvw-media-pick" data-multi="0" data-type="%s" data-target="%s">Escolher</button> <button type="button" class="button-link wvw-media-clear" data-target="%s">Remover</button>', 'file' === $f[1] ? 'application/pdf' : 'image', esc_attr( $id ), esc_attr( $id ) );
			} else {
				printf( '<input type="%s" id="%s" name="%s" value="%s" class="regular-text">', 'url' === $f[1] ? 'url' : 'text', esc_attr( $id ), esc_attr( $name ), esc_attr( $v ) );
			}
			if ( $f[2] ) {
				echo '<p class="description">' . esc_html( $f[2] ) . '</p>';
			}
			echo '</td></tr>';
		}
		echo '</table>';
	}
	submit_button( 'Guardar definições' );
	echo '</form>';

	echo '<hr><h2>Conteúdo inicial</h2>';
	if ( get_option( 'wvw_seeded' ) ) {
		echo '<p>O conteúdo inicial já foi instalado em ' . esc_html( get_option( 'wvw_seeded' ) ) . '.</p>';
	} else {
		echo '<p>Cria as páginas, os cases, os artigos, a equipa, as imagens e o PDF de credenciais. Faz-se uma única vez, num site novo.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'wvw_seed' );
		echo '<input type="hidden" name="action" value="wvw_seed">';
		submit_button( 'Instalar conteúdo inicial', 'primary', 'submit', false );
		echo '</form>';
	}
	echo '</div>';
}
