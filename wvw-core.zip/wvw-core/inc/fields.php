<?php
defined( 'ABSPATH' ) || exit;

add_action( 'add_meta_boxes', function ( $post_type, $post ) {
	$key = wvw_schema_key_for( $post );
	if ( ! $key ) {
		return;
	}
	foreach ( wvw_schemas()[ $key ] as $i => $box ) {
		add_meta_box( 'wvw_box_' . $i, $box['title'], 'wvw_render_box', $post_type, 'normal', 'high', array( 'fields' => $box['fields'] ) );
	}
	if ( 'page' === $post_type && in_array( $post->post_name, array( 'home', 'about', 'services', 'contact' ), true ) ) {
		remove_post_type_support( 'page', 'editor' );
	}
}, 10, 2 );

/* The fixed pages (home/about/services/contact) are edited only through fields. */
add_action( 'admin_head-post.php', function () {
	global $post;
	if ( $post && 'page' === $post->post_type && in_array( $post->post_name, array( 'home', 'about', 'services', 'contact' ), true ) ) {
		echo '<style>#postdivrich{display:none}</style>';
		echo '<div class="notice notice-info"><p><strong>Página com estrutura fixa.</strong> Edite os textos e imagens nos campos abaixo. O endereço (slug) desta página não deve ser alterado.</p></div>';
	}
} );

function wvw_render_box( $post, $box ) {
	wp_nonce_field( 'wvw_save_fields', 'wvw_fields_nonce' );
	echo '<div class="wvw-fields">';
	foreach ( $box['args']['fields'] as $f ) {
		$id    = 'wvw_' . $f['key'];
		$value = get_post_meta( $post->ID, '_wvw_' . $f['key'], true );
		echo '<div class="wvw-field wvw-type-' . esc_attr( $f['type'] ) . '">';
		echo '<label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . '</label>';
		switch ( $f['type'] ) {
			case 'textarea':
				printf( '<textarea id="%1$s" name="%1$s" rows="%2$d">%3$s</textarea>', esc_attr( $id ), (int) ( $f['rows'] ?? 3 ), esc_textarea( $value ) );
				break;
			case 'select':
				printf( '<select id="%1$s" name="%1$s">', esc_attr( $id ) );
				foreach ( $f['options'] as $ok => $ol ) {
					printf( '<option value="%s"%s>%s</option>', esc_attr( $ok ), selected( $value, $ok, false ), esc_html( $ol ) );
				}
				echo '</select>';
				break;
			case 'post':
				printf( '<select id="%1$s" name="%1$s"><option value="">—</option>', esc_attr( $id ) );
				foreach ( get_posts( array( 'post_type' => $f['post_type'], 'numberposts' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) ) as $p ) {
					printf( '<option value="%d"%s>%s</option>', $p->ID, selected( (int) $value, $p->ID, false ), esc_html( get_the_title( $p ) ) );
				}
				echo '</select>';
				break;
			case 'image':
			case 'gallery':
				$multi = 'gallery' === $f['type'];
				printf( '<input type="hidden" id="%1$s" name="%1$s" value="%2$s" class="wvw-media-input">', esc_attr( $id ), esc_attr( $value ) );
				echo '<div class="wvw-media-preview" data-multi="' . ( $multi ? '1' : '0' ) . '">';
				foreach ( wvw_ids( $value ) as $aid ) {
					echo '<span class="wvw-thumb" data-id="' . (int) $aid . '">' . wp_get_attachment_image( $aid, 'thumbnail' ) . '</span>';
				}
				echo '</div>';
				printf( '<button type="button" class="button wvw-media-pick" data-multi="%d" data-target="%s">%s</button> ', $multi ? 1 : 0, esc_attr( $id ), $multi ? 'Escolher imagens' : 'Escolher imagem' );
				printf( '<button type="button" class="button-link wvw-media-clear" data-target="%s">Remover</button>', esc_attr( $id ) );
				break;
			default:
				printf( '<input type="%4$s" id="%1$s" name="%1$s" value="%2$s" class="widefat"%3$s>', esc_attr( $id ), esc_attr( $value ), '', in_array( $f['type'], array( 'url', 'email' ), true ) ? $f['type'] : 'text' );
		}
		if ( ! empty( $f['help'] ) ) {
			echo '<p class="description">' . esc_html( $f['help'] ) . '</p>';
		}
		echo '</div>';
	}
	echo '</div>';
}

add_action( 'save_post', function ( $post_id, $post ) {
	if ( ! isset( $_POST['wvw_fields_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wvw_fields_nonce'] ) ), 'wvw_save_fields' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$key = wvw_schema_key_for( $post );
	if ( ! $key ) {
		return;
	}
	foreach ( wvw_schemas()[ $key ] as $box ) {
		foreach ( $box['fields'] as $f ) {
			$name = 'wvw_' . $f['key'];
			if ( ! isset( $_POST[ $name ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $name ] );
			switch ( $f['type'] ) {
				case 'textarea':
					$val = sanitize_textarea_field( $raw );
					break;
				case 'url':
					$val = esc_url_raw( $raw );
					break;
				case 'email':
					$val = sanitize_email( $raw );
					break;
				case 'image':
				case 'gallery':
					$val = implode( ',', wvw_ids( $raw ) );
					break;
				case 'post':
					$val = $raw ? absint( $raw ) : '';
					break;
				default:
					$val = sanitize_text_field( $raw );
			}
			update_post_meta( $post_id, '_wvw_' . $f['key'], $val );
		}
	}
}, 10, 2 );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'toplevel_page_wvw-settings' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_script( 'wvw-admin', WVW_CORE_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), WVW_CORE_VERSION, true );
	wp_enqueue_style( 'wvw-admin', WVW_CORE_URL . 'assets/admin.css', array(), WVW_CORE_VERSION );
} );

/* Guidance under "Featured image" so the team uploads the right size and format. */
add_filter( 'admin_post_thumbnail_html', function ( $html, $post_id ) {
	$tips = array(
		'case'  => 'Imagem do cartão e do topo do projeto. Quadrada ou 4:5, mín. 1200 px, JPG em RGB (nunca CMYK), até 500 KB.',
		'trend' => 'Capa do artigo. Horizontal 3:2 ou 16:10, mín. 1600 px, JPG em RGB, até 400 KB. Sem imagem, o site usa a capa tipográfica com o número em destaque.',
		'team'  => 'Retrato vertical 4:5, mín. 800 × 1000 px, com a cara no terço de cima e fundo igual ao das outras fotos.',
		'page'  => 'Imagem usada quando a página é partilhada (LinkedIn, WhatsApp). 1200 × 630 px.',
	);
	$type = get_post_type( $post_id );
	if ( isset( $tips[ $type ] ) ) {
		$html .= '<p class="description" style="margin-top:8px">' . esc_html( $tips[ $type ] ) . ' Preencha o “Texto alternativo” da imagem (descrição para quem não vê).</p>';
	}
	return $html;
}, 10, 2 );
