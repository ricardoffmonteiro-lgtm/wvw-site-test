<?php
/**
 * Contact form ("send us a brief"): REST endpoint, spam checks, storage as a private post and email.
 * No nonce on purpose: pages may be served from cache, so protection is a honeypot, a minimum fill time and a rate limit.
 */
defined( 'ABSPATH' ) || exit;

add_action( 'rest_api_init', function () {
	register_rest_route( 'wvw/v1', '/brief', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'wvw_handle_brief',
	) );
} );

function wvw_handle_brief( WP_REST_Request $req ) {
	$p = $req->get_json_params() ?: $req->get_body_params();

	// Honeypot and timing: bots fill hidden fields and submit instantly.
	if ( ! empty( $p['website'] ) || ( isset( $p['t'] ) && ( time() * 1000 - (int) $p['t'] ) < 3000 ) ) {
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	// Rate limit: 5 briefs per IP per hour.
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	$rk  = 'wvw_rl_' . md5( $ip );
	$cnt = (int) get_transient( $rk );
	if ( $cnt >= 5 ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'Too many messages. Please email us directly.' ), 429 );
	}

	$name  = sanitize_text_field( $p['name'] ?? '' );
	$org   = sanitize_text_field( $p['org'] ?? '' );
	$email = sanitize_email( $p['email'] ?? '' );
	$mk    = sanitize_text_field( $p['market'] ?? '' );
	$needs = implode( ', ', array_map( 'sanitize_text_field', (array) ( $p['needs'] ?? array() ) ) );
	$msg   = sanitize_textarea_field( $p['message'] ?? '' );
	$ok    = ! empty( $p['consent'] );

	if ( ! $name || ! $org || ! is_email( $email ) || ! $msg || ! $ok ) {
		return new WP_REST_Response( array( 'ok' => false, 'error' => 'Please fill in all required fields.' ), 400 );
	}
	set_transient( $rk, $cnt + 1, HOUR_IN_SECONDS );

	$body = "Name: {$name}\nOrganisation: {$org}\nEmail: {$email}\nTarget market: {$mk}\nNeeds: {$needs}\n\n{$msg}";

	$id = wp_insert_post( array(
		'post_type'    => 'brief',
		'post_status'  => 'private',
		'post_title'   => $org . ' · ' . $name,
		'post_content' => $body,
	) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_wvw_brief_email', $email );
		update_post_meta( $id, '_wvw_brief_needs', $needs );
		update_post_meta( $id, '_wvw_brief_body', $body );
	}

	$to   = wvw_opt( 'brief_to', wvw_opt( 'contact_email', get_option( 'admin_email' ) ) );
	$sent = wp_mail(
		array_map( 'trim', explode( ',', $to ) ),
		'New brief from ' . $org,
		$body . "\n\n---\nSent from " . home_url( '/contact/' ),
		array( 'Reply-To: ' . $name . ' <' . $email . '>' )
	);
	if ( $id ) {
		update_post_meta( $id, '_wvw_brief_mailed', $sent ? 'yes' : 'no' );
	}

	return new WP_REST_Response( array( 'ok' => true ), 200 );
}

/* Read-only view of a received brief. */
add_action( 'add_meta_boxes_brief', function ( $post ) {
	add_meta_box( 'wvw_brief_view', 'Brief', function ( $post ) {
		echo '<pre style="white-space:pre-wrap;font-size:14px;line-height:1.6;margin:0">' . esc_html( get_post_meta( $post->ID, '_wvw_brief_body', true ) ) . '</pre>';
		$m = get_post_meta( $post->ID, '_wvw_brief_mailed', true );
		echo '<p class="description">' . ( 'yes' === $m ? 'Enviado por email.' : 'Atenção: o envio por email falhou. Verifique o FluentSMTP.' ) . '</p>';
	}, 'brief', 'normal', 'high' );
} );
