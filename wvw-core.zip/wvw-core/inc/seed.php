<?php
/**
 * One-time installer for the initial content (pages, cases, trends, team, media, settings).
 * Run from WVW › Definições › "Instalar conteúdo inicial", or with WP-CLI: wp wvw seed
 */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_post_wvw_seed', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wvw_seed' ) ) {
		wp_die( 'Sem permissão.' );
	}
	wvw_seed();
	wp_safe_redirect( admin_url( 'admin.php?page=wvw-settings&wvw_seeded=1' ) );
	exit;
} );

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'wvw seed', function ( $args, $assoc ) {
		$r = wvw_seed( isset( $assoc['force'] ) );
		WP_CLI::success( $r );
	} );
}

function wvw_seed( $force = false ) {
	if ( get_option( 'wvw_seeded' ) && ! $force ) {
		return 'Já instalado.';
	}
	$dir  = WVW_CORE_DIR . 'seed/';
	$data = json_decode( (string) file_get_contents( $dir . 'content.json' ), true );
	if ( ! $data ) {
		return 'content.json em falta.';
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$media = array();
	foreach ( $data['media'] as $key => $m ) {
		$existing = get_posts( array( 'post_type' => 'attachment', 'meta_key' => '_wvw_seed_key', 'meta_value' => $key, 'numberposts' => 1, 'fields' => 'ids' ) );
		if ( $existing ) {
			$media[ $key ] = $existing[0];
			continue;
		}
		$tmp = wp_tempnam( $m['file'] );
		copy( $dir . 'media/' . $m['file'], $tmp );
		$id = media_handle_sideload( array( 'name' => $m['file'], 'tmp_name' => $tmp ), 0, $m['title'] ?? null );
		if ( is_wp_error( $id ) ) {
			continue;
		}
		update_post_meta( $id, '_wvw_seed_key', $key );
		if ( ! empty( $m['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', $m['alt'] );
		}
		$media[ $key ] = $id;
	}

	$posts   = array();
	$resolve = function ( $v ) use ( &$media, &$posts ) {
		if ( ! is_string( $v ) || false === strpos( $v, '@' ) ) {
			return $v;
		}
		$parts = array_map( 'trim', explode( ',', $v ) );
		$out   = array();
		foreach ( $parts as $p ) {
			if ( 0 === strpos( $p, '@media:' ) ) {
				$out[] = $media[ substr( $p, 7 ) ] ?? '';
			} elseif ( 0 === strpos( $p, '@post:' ) ) {
				$out[] = $posts[ substr( $p, 6 ) ] ?? '';
			} else {
				return $v;
			}
		}
		return implode( ',', array_filter( $out ) );
	};
	$make = function ( $type, $item ) use ( $resolve, &$posts ) {
		$found = get_posts( array( 'post_type' => $type, 'name' => $item['slug'], 'post_status' => 'any', 'numberposts' => 1 ) );
		$found = $found ? $found[0] : null;
		$args  = array(
			'post_type'    => $type,
			'post_status'  => 'publish',
			'post_name'    => $item['slug'],
			'post_title'   => $item['title'],
			'post_content' => $item['content'] ?? '',
			'post_excerpt' => $item['excerpt'] ?? '',
			'menu_order'   => $item['order'] ?? 0,
		);
		if ( ! empty( $item['date'] ) ) {
			$args['post_date'] = $item['date'] . ' 09:00:00';
		}
		if ( $found ) {
			$args['ID'] = $found->ID;
		}
		$id = wp_insert_post( $args );
		foreach ( $item['fields'] ?? array() as $k => $v ) {
			update_post_meta( $id, '_wvw_' . $k, $resolve( $v ) );
		}
		if ( ! empty( $item['thumb'] ) ) {
			set_post_thumbnail( $id, (int) $resolve( $item['thumb'] ) );
		}
		$posts[ $type . '/' . $item['slug'] ] = $id;
		return $id;
	};

	foreach ( $data['cases'] as $c ) {
		$make( 'case', $c );
	}
	foreach ( $data['trends'] as $t ) {
		$make( 'trend', $t );
	}
	foreach ( $data['team'] as $t ) {
		$make( 'team', $t );
	}
	foreach ( $data['pages'] as $p ) {
		$make( 'page', $p );
	}

	$settings = array();
	foreach ( $data['settings'] as $k => $v ) {
		$settings[ $k ] = $resolve( $v );
	}
	update_option( 'wvw_settings', $settings );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $posts['page/home'] ?? 0 );
	update_option( 'blogname', 'We Visit Worlds' );
	update_option( 'blogdescription', 'Tourism marketing & communication' );
	update_option( 'default_comment_status', 'closed' );
	if ( ! get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}
	if ( ! empty( $posts['page/privacy-cookies'] ) ) {
		update_option( 'wp_page_for_privacy_policy', $posts['page/privacy-cookies'] );
	}
	// Remove WordPress demo content if still there.
	foreach ( array( 'hello-world' => 'post', 'sample-page' => 'page' ) as $slug => $type ) {
		$p = get_page_by_path( $slug, OBJECT, $type );
		if ( $p ) {
			wp_delete_post( $p->ID, true );
		}
	}
	flush_rewrite_rules();
	do_action( 'wvw_after_seed' );
	update_option( 'wvw_seeded', current_time( 'Y-m-d H:i' ) );
	return sprintf( 'Instalado: %d media, %d conteúdos.', count( $media ), count( $posts ) );
}
