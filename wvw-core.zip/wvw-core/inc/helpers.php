<?php
defined( 'ABSPATH' ) || exit;

/**
 * Read a WVW field for a post (meta "_wvw_{key}"), falling back to a default.
 */
function wvw_get( $key, $post_id = null, $default = '' ) {
	$post_id = $post_id ?: get_the_ID();
	if ( ! $post_id ) {
		return $default;
	}
	$v = get_post_meta( $post_id, '_wvw_' . $key, true );
	return ( '' === $v || null === $v || false === $v ) ? $default : $v;
}

/** Read a field from a page identified by slug (home, about, services, contact). */
function wvw_page_get( $slug, $key, $default = '' ) {
	$page = get_page_by_path( $slug );
	return $page ? wvw_get( $key, $page->ID, $default ) : $default;
}

/** Read a site-wide setting. */
function wvw_opt( $key, $default = '' ) {
	$o = get_option( 'wvw_settings', array() );
	return ( isset( $o[ $key ] ) && '' !== $o[ $key ] ) ? $o[ $key ] : $default;
}

/** Split a textarea into non-empty trimmed lines. */
function wvw_lines( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ), 'strlen' ) );
}

/** Split "a | b | c" lines into arrays. */
function wvw_rows( $text ) {
	return array_map( function ( $l ) {
		return array_map( 'trim', explode( '|', $l ) );
	}, wvw_lines( $text ) );
}

/** Comma list to array. */
function wvw_list( $text ) {
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) $text ) ), 'strlen' ) );
}

/** Comma-separated attachment ids to int array. */
function wvw_ids( $text ) {
	return array_values( array_filter( array_map( 'absint', explode( ',', (string) $text ) ) ) );
}

/** Markets used by Cases (key => label). */
function wvw_markets() {
	return array(
		'portugal'      => 'Portugal',
		'spain'         => 'Spain',
		'north-america' => 'North America',
		'brazil'        => 'South America',
	);
}

/** Parse case KPI lines: LABEL | value | decimals | suffix | description */
function wvw_kpis( $text ) {
	$out = array();
	foreach ( wvw_rows( $text ) as $r ) {
		if ( count( $r ) < 2 ) {
			continue;
		}
		$out[] = array(
			'label' => $r[0] ?? '',
			'value' => (float) str_replace( ',', '.', $r[1] ?? '0' ),
			'dec'   => (int) ( $r[2] ?? 0 ),
			'suf'   => $r[3] ?? '',
			'desc'  => $r[4] ?? '',
		);
	}
	return $out;
}

/** Estimated reading time in minutes. */
function wvw_reading_time( $post_id = null ) {
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ?: get_the_ID() ) ) );
	return max( 2, (int) round( $words / 200 ) );
}
