<?php
defined( 'ABSPATH' ) || exit;

/**
 * Field definitions. Each schema is a list of boxes; each box has fields.
 * Field: key, label, type (text|textarea|image|gallery|select|post|url|email), help, options, post_type, rows.
 * Pages are matched by slug (home, about, services, contact).
 */
function wvw_schemas() {
	$svc = array();
	for ( $i = 1; $i <= 6; $i++ ) {
		$svc[] = array( 'key' => "svc{$i}_title", 'label' => "Serviço {$i} · título", 'type' => 'text' );
		$svc[] = array( 'key' => "svc{$i}_short", 'label' => "Serviço {$i} · resumo (uma linha)", 'type' => 'text' );
		$svc[] = array( 'key' => "svc{$i}_long", 'label' => "Serviço {$i} · descrição", 'type' => 'textarea', 'rows' => 3 );
	}
	$steps = array();
	for ( $i = 1; $i <= 6; $i++ ) {
		$steps[] = array( 'key' => "step{$i}_title", 'label' => "Passo {$i} · título", 'type' => 'text' );
		$steps[] = array( 'key' => "step{$i}_text", 'label' => "Passo {$i} · texto", 'type' => 'text' );
	}
	$markets = array();
	for ( $i = 1; $i <= 3; $i++ ) {
		$markets[] = array( 'key' => "market{$i}_name", 'label' => "Mercado {$i} · nome", 'type' => 'text' );
		$markets[] = array( 'key' => "market{$i}_sub", 'label' => "Mercado {$i} · detalhe", 'type' => 'text' );
	}

	return array(
		'page:home'     => array(
			array( 'title' => 'Topo (hero)', 'fields' => array(
				array( 'key' => 'hero_eyebrow', 'label' => 'Texto pequeno por cima do título', 'type' => 'text' ),
				array( 'key' => 'hero_title', 'label' => 'Título principal', 'type' => 'text' ),
				array( 'key' => 'hero_sub', 'label' => 'Subtítulo', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'hero_image', 'label' => 'Imagem do topo', 'type' => 'image', 'help' => 'Vertical ou quadrada, mínimo 1200 px de altura.' ),
				array( 'key' => 'hero_cta1', 'label' => 'Botão 1 (vai para Contact)', 'type' => 'text' ),
				array( 'key' => 'hero_cta2', 'label' => 'Botão 2 (vai para Our work)', 'type' => 'text' ),
			) ),
			array( 'title' => 'Clientes e prémio', 'fields' => array(
				array( 'key' => 'clients_label', 'label' => 'Título da faixa de clientes', 'type' => 'text' ),
				array( 'key' => 'client_logos', 'label' => 'Logótipos de clientes', 'type' => 'gallery', 'help' => 'PNG com fundo transparente. Arraste para mudar a ordem.' ),
				array( 'key' => 'award_title', 'label' => 'Prémio · linha 1', 'type' => 'text' ),
				array( 'key' => 'award_sub', 'label' => 'Prémio · linha 2', 'type' => 'text', 'help' => 'Aparece a seguir a “Winner”. Ex.: 2026' ),
				array( 'key' => 'award_logo', 'label' => 'Prémio · logótipo', 'type' => 'image' ),
			) ),
			array( 'title' => 'Case em destaque', 'fields' => array(
				array( 'key' => 'featured_case', 'label' => 'Case', 'type' => 'post', 'post_type' => 'case', 'help' => 'Mostra a imagem, o resumo e os KPIs deste case.' ),
			) ),
			array( 'title' => 'Mercados', 'fields' => array_merge( array(
				array( 'key' => 'markets_title', 'label' => 'Título', 'type' => 'text' ),
				array( 'key' => 'markets_text', 'label' => 'Texto', 'type' => 'textarea', 'rows' => 2 ),
			), $markets ) ),
			array( 'title' => 'Serviços (resumo)', 'fields' => array(
				array( 'key' => 'services_text', 'label' => 'Texto ao lado da lista', 'type' => 'textarea', 'rows' => 2, 'help' => 'A lista de serviços vem da página Services.' ),
			) ),
			array( 'title' => 'Reconhecimento', 'fields' => array(
				array( 'key' => 'recog_title', 'label' => 'Título', 'type' => 'text' ),
				array( 'key' => 'recog_text', 'label' => 'Texto', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'recog_link_case', 'label' => 'Ligação para o case', 'type' => 'post', 'post_type' => 'case' ),
				array( 'key' => 'recog_image', 'label' => 'Imagem', 'type' => 'image' ),
			) ),
			array( 'title' => 'Sobre nós (resumo)', 'fields' => array(
				array( 'key' => 'about_title', 'label' => 'Título', 'type' => 'text' ),
				array( 'key' => 'about_text', 'label' => 'Texto', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'about_image', 'label' => 'Foto da equipa', 'type' => 'image', 'help' => 'Aparece inteira, sem cortes.' ),
			) ),
		),
		'page:about'    => array(
			array( 'title' => 'Conteúdo da página About', 'fields' => array(
				array( 'key' => 'tagline', 'label' => 'Frase ao lado do título', 'type' => 'text' ),
				array( 'key' => 'team_image', 'label' => 'Foto da equipa', 'type' => 'image' ),
				array( 'key' => 'weare_lead', 'label' => '“We are” · frase principal', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'weare_p1', 'label' => '“We are” · parágrafo 1', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'weare_p2', 'label' => '“We are” · parágrafo 2', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'join_title', 'label' => '“Join us” · título', 'type' => 'text' ),
				array( 'key' => 'join_text', 'label' => '“Join us” · texto', 'type' => 'text' ),
			) ),
		),
		'page:services' => array(
			array( 'title' => 'Introdução', 'fields' => array(
				array( 'key' => 'tagline', 'label' => 'Frase ao lado do título', 'type' => 'text' ),
				array( 'key' => 'intro', 'label' => 'Introdução', 'type' => 'textarea', 'rows' => 2 ),
			) ),
			array( 'title' => 'Os 6 serviços', 'fields' => $svc ),
			array( 'title' => 'Como trabalhamos', 'fields' => array_merge( array(
				array( 'key' => 'steps_title', 'label' => 'Título', 'type' => 'text' ),
				array( 'key' => 'steps_text', 'label' => 'Texto', 'type' => 'textarea', 'rows' => 2 ),
			), $steps ) ),
			array( 'title' => 'Media e branded content', 'fields' => array(
				array( 'key' => 'media_list', 'label' => 'Media (uma por linha)', 'type' => 'textarea', 'rows' => 6 ),
				array( 'key' => 'branded_list', 'label' => 'Branded content (um por linha)', 'type' => 'textarea', 'rows' => 6 ),
			) ),
			array( 'title' => 'Credenciais', 'fields' => array(
				array( 'key' => 'cred_title', 'label' => 'Título', 'type' => 'text' ),
				array( 'key' => 'cred_text', 'label' => 'Texto', 'type' => 'textarea', 'rows' => 2 ),
			) ),
		),
		'page:contact'  => array(
			array( 'title' => 'Conteúdo da página Contact', 'fields' => array(
				array( 'key' => 'tagline', 'label' => 'Frase ao lado do título', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'form_title', 'label' => 'Título do formulário', 'type' => 'text' ),
				array( 'key' => 'needs', 'label' => 'Opções “What do you need?”', 'type' => 'text', 'help' => 'Separadas por vírgulas.' ),
				array( 'key' => 'consent', 'label' => 'Texto do consentimento', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'success', 'label' => 'Mensagem depois de enviar', 'type' => 'textarea', 'rows' => 2 ),
			) ),
		),
		'case'          => array(
			array( 'title' => 'Dados do case', 'fields' => array(
				array( 'key' => 'market_key', 'label' => 'Mercado (para o filtro)', 'type' => 'select', 'options' => wvw_markets() ),
				array( 'key' => 'market_label', 'label' => 'Etiqueta do mercado', 'type' => 'text', 'help' => 'Ex.: Portuguese market' ),
				array( 'key' => 'client', 'label' => 'Cliente', 'type' => 'text' ),
				array( 'key' => 'country', 'label' => 'País / mercado (ficha técnica)', 'type' => 'text' ),
				array( 'key' => 'year', 'label' => 'Ano', 'type' => 'text', 'help' => 'Vazio = não aparece.' ),
				array( 'key' => 'channels', 'label' => 'Canais', 'type' => 'text', 'help' => 'Ex.: TV · Digital · OOH' ),
				array( 'key' => 'award', 'label' => 'Prémio', 'type' => 'text', 'help' => 'Vazio = não aparece. Se preenchido, mostra um selo no cartão.' ),
				array( 'key' => 'lead', 'label' => 'Frase de abertura', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'summary', 'label' => 'Resumo (cartões e listas)', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'tags', 'label' => 'Etiquetas do cartão', 'type' => 'text', 'help' => 'Separadas por vírgulas. Ex.: TV, Digital, OOH' ),
				array( 'key' => 'services', 'label' => 'O que fizemos', 'type' => 'text', 'help' => 'Separados por vírgulas.' ),
			) ),
			array( 'title' => 'Resultados', 'fields' => array(
				array( 'key' => 'kpis', 'label' => 'KPIs (um por linha)', 'type' => 'textarea', 'rows' => 5, 'help' => 'Formato: CANAL | número | casas decimais | sufixo | descrição. Ex.: TELEVISION | 10.5 | 1 | M | impressions. Vazio = a secção não aparece.' ),
				array( 'key' => 'presence', 'label' => 'Frase de presença física', 'type' => 'textarea', 'rows' => 2 ),
			) ),
			array( 'title' => 'Galeria', 'fields' => array(
				array( 'key' => 'gallery', 'label' => 'Imagens', 'type' => 'gallery', 'help' => 'Até 3 imagens. A imagem principal é a “Imagem de destaque”, na coluna da direita.' ),
			) ),
		),
		'trend'         => array(
			array( 'title' => 'Dados do artigo', 'fields' => array(
				array( 'key' => 'category', 'label' => 'Tema', 'type' => 'text', 'help' => 'Ex.: Markets, Climate, AI & discovery. Usado no filtro.' ),
				array( 'key' => 'cover_value', 'label' => 'Capa · número', 'type' => 'text', 'help' => 'Usado quando o artigo não tem imagem de destaque. Ex.: 38%' ),
				array( 'key' => 'cover_label', 'label' => 'Capa · legenda', 'type' => 'text' ),
				array( 'key' => 'key_value', 'label' => 'Número em destaque', 'type' => 'text', 'help' => 'Aparece onde escrever [keystat] no texto.' ),
				array( 'key' => 'key_text', 'label' => 'Número em destaque · texto', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'key_source', 'label' => 'Número em destaque · fonte', 'type' => 'text' ),
				array( 'key' => 'sources', 'label' => 'Fontes (uma por linha)', 'type' => 'textarea', 'rows' => 4, 'help' => 'Formato: Nome da fonte | https://endereço' ),
			) ),
		),
		'team'          => array(
			array( 'title' => 'Dados', 'fields' => array(
				array( 'key' => 'role', 'label' => 'Cargo', 'type' => 'text', 'help' => 'Vazio = só aparece a cidade.' ),
				array( 'key' => 'city', 'label' => 'Cidade', 'type' => 'text' ),
			) ),
		),
	);
}

/** Return the schema key for a post, or null. */
function wvw_schema_key_for( $post ) {
	if ( ! $post ) {
		return null;
	}
	if ( 'page' === $post->post_type ) {
		$k = 'page:' . $post->post_name;
		return isset( wvw_schemas()[ $k ] ) ? $k : null;
	}
	return isset( wvw_schemas()[ $post->post_type ] ) ? $post->post_type : null;
}
