<?php
defined( 'ABSPATH' ) || exit;

/* No comments anywhere on this site. */
add_action( 'init', function () {
	foreach ( get_post_types() as $pt ) {
		if ( post_type_supports( $pt, 'comments' ) ) {
			remove_post_type_support( $pt, 'comments' );
			remove_post_type_support( $pt, 'trackbacks' );
		}
	}
}, 100 );
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );
add_filter( 'comments_array', '__return_empty_array', 10 );
add_action( 'admin_menu', function () {
	remove_menu_page( 'edit-comments.php' );
	remove_menu_page( 'edit.php' ); // Blog posts are not used; Trends replace them.
} );
add_action( 'admin_bar_menu', function ( $bar ) {
	$bar->remove_node( 'comments' );
	$bar->remove_node( 'new-post' );
}, 999 );

/* Remove emoji scripts and other head clutter. */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );

/* Keep the four structural pages from being trashed by accident. */
add_filter( 'pre_trash_post', function ( $trash, $post ) {
	if ( 'page' === $post->post_type && in_array( $post->post_name, array( 'home', 'about', 'services', 'contact' ), true ) ) {
		wp_die( 'Esta página faz parte da estrutura do site e não pode ser apagada.' );
	}
	return $trash;
}, 10, 2 );

/* Allow PDF uploads to be picked for credentials (core already allows PDFs). Shortcode for the key statistic in Trends. */
add_shortcode( 'keystat', function () {
	$id = get_the_ID();
	$v  = wvw_get( 'key_value', $id );
	if ( ! $v ) {
		return '';
	}
	return '<div class="keystat rv"><b>' . esc_html( $v ) . '</b><div><p>' . esc_html( wvw_get( 'key_text', $id ) ) . '</p>' .
		( wvw_get( 'key_source', $id ) ? '<small>Source: ' . esc_html( wvw_get( 'key_source', $id ) ) . '</small>' : '' ) . '</div></div>';
} );
