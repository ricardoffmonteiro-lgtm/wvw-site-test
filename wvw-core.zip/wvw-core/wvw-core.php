<?php
/**
 * Plugin Name:       WVW Core
 * Description:       Conteúdos e funcionalidades do site We Visit Worlds: Cases, Trends, Equipa, campos editáveis das páginas, formulário de briefs e conteúdo inicial. Necessário para o tema "We Visit Worlds".
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            We Visit Worlds
 * Text Domain:       wvw-core
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

define( 'WVW_CORE_VERSION', '1.0.0' );
define( 'WVW_CORE_FILE', __FILE__ );
define( 'WVW_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'WVW_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once WVW_CORE_DIR . 'inc/helpers.php';
require_once WVW_CORE_DIR . 'inc/post-types.php';
require_once WVW_CORE_DIR . 'inc/schemas.php';
require_once WVW_CORE_DIR . 'inc/fields.php';
require_once WVW_CORE_DIR . 'inc/settings.php';
require_once WVW_CORE_DIR . 'inc/brief.php';
require_once WVW_CORE_DIR . 'inc/cleanup.php';
require_once WVW_CORE_DIR . 'inc/seed.php';

register_activation_hook( __FILE__, function () {
	wvw_register_post_types();
	flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
