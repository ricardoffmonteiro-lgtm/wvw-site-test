/* WVW Core: image and gallery pickers for the editable fields. */
jQuery(function ($) {
  function render($input, ids) {
    var $prev = $input.siblings('.wvw-media-preview');
    $prev.empty();
    ids.forEach(function (id) {
      var att = wp.media.attachment(id);
      att.fetch().then(function () {
        var s = att.get('sizes');
        var url = s && s.thumbnail ? s.thumbnail.url : att.get('url');
        var $t = $('<span class="wvw-thumb"></span>').attr('data-id', id);
        if (att.get('type') === 'image') { $t.append($('<img>').attr('src', url)); }
        else { $t.addClass('wvw-file').text(att.get('filename')); }
        $prev.append($t);
      });
    });
  }
  function sync($prev) {
    var ids = $prev.find('.wvw-thumb').map(function () { return $(this).data('id'); }).get();
    $prev.siblings('.wvw-media-input').val(ids.join(','));
  }
  $('.wvw-media-preview[data-multi="1"]').sortable({ items: '.wvw-thumb', update: function () { sync($(this)); } });

  $(document).on('click', '.wvw-media-pick', function (e) {
    e.preventDefault();
    var $btn = $(this), multi = $btn.data('multi') === 1 || $btn.data('multi') === '1';
    var $input = $('#' + $btn.data('target'));
    var type = $btn.data('type') || 'image';
    var frame = wp.media({ title: multi ? 'Escolher imagens' : 'Escolher', multiple: multi ? 'add' : false, library: type === 'any' ? {} : { type: type } });
    frame.on('open', function () {
      var sel = frame.state().get('selection');
      ($input.val() || '').split(',').filter(Boolean).forEach(function (id) { var a = wp.media.attachment(id); a.fetch(); sel.add(a); });
    });
    frame.on('select', function () {
      var ids = frame.state().get('selection').map(function (a) { return a.id; });
      $input.val(ids.join(','));
      render($input, ids);
    });
    frame.open();
  });
  $(document).on('click', '.wvw-media-clear', function (e) {
    e.preventDefault();
    var $input = $('#' + $(this).data('target'));
    $input.val('');
    $input.siblings('.wvw-media-preview').empty();
  });
});
